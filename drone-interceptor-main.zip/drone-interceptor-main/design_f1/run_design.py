#!/usr/bin/env python
"""
Dimensionamento/ottimizzazione multirotore con FAST-UAV — script standalone (no notebook).

Uso:
    python run_design.py                      # ottimizzazione MDO completa
    python run_design.py --mda                # sola analisi (MDA), senza ottimizzatore
    python run_design.py --source altro.xml   # file sorgente diverso
    python run_design.py --n2                 # genera anche il diagramma N2 (html)

Output in ./workdir/problem_outputs.xml + riepilogo a terminale.
"""
import argparse
import logging
import os
import os.path as pth
import sys

import fastoad.api as oad

HERE = pth.dirname(pth.abspath(__file__))
DEFAULT_CONFIG = pth.join(HERE, "multirotor_mdo.yaml")
DEFAULT_SOURCE = pth.join(HERE, "problem_inputs.xml")
WORKDIR = pth.join(HERE, "workdir")

# Variabili chiave da stampare a fine run
SUMMARY_VARS = [
    ("data:weight:mtow", "kg", "MTOW"),
    ("data:weight:misc:mass", "kg", "Payload (camera)"),
    ("data:weight:propulsion:multirotor:battery:mass", "kg", "Massa batteria"),
    ("data:propulsion:multirotor:propeller:diameter", "in", "Diametro elica"),
    ("data:propulsion:multirotor:motor:power:max", "W", "Potenza max motore"),
    ("data:propulsion:multirotor:battery:voltage", "V", "Tensione batteria"),
    ("data:propulsion:multirotor:battery:capacity", "A*s", "Capacità batteria"),
    ("mission:sizing:main_route:cruise:speed:multirotor", "m/s", "Velocità crociera"),
    ("data:performance:endurance:hover:max", "min", "Autonomia hover max"),
    ("data:performance:endurance:cruise", "min", "Autonomia crociera"),
]


def print_summary(output_file: str) -> None:
    variables = oad.DataFile(output_file)
    names = {v.name: v for v in variables}
    print("\n" + "=" * 60)
    print("RISULTATI DEL DIMENSIONAMENTO")
    print("=" * 60)
    for name, unit, label in SUMMARY_VARS:
        var = names.get(name)
        if var is None:
            continue
        try:
            val = float(var.value[0]) if hasattr(var.value, "__len__") else float(var.value)
        except (TypeError, ValueError):
            continue
        print(f"  {label:<28} {val:>12.3f} {var.units or unit}")
    print("=" * 60)
    print(f"Output completo: {output_file}")


def main() -> int:
    parser = argparse.ArgumentParser(description="FAST-UAV multirotor design (standalone)")
    parser.add_argument("--config", default=DEFAULT_CONFIG, help="file di configurazione YAML")
    parser.add_argument("--source", default=DEFAULT_SOURCE, help="file XML dei dati sorgente")
    parser.add_argument("--mda", action="store_true", help="esegui solo l'analisi (senza ottimizzatore)")
    parser.add_argument("--n2", action="store_true", help="genera il diagramma N2 in workdir/n2.html")
    parser.add_argument("-v", "--verbose", action="store_true", help="log INFO di FAST-OAD/OpenMDAO")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format="%(levelname)-8s: %(message)s",
    )

    os.makedirs(WORKDIR, exist_ok=True)

    if args.n2:
        n2_file = pth.join(WORKDIR, "n2.html")
        oad.write_n2(args.config, n2_file, overwrite=True)
        print(f"Diagramma N2: {n2_file}")

    # 1. Genera il file di input del problema a partire dal file sorgente
    print(f"Config : {args.config}")
    print(f"Source : {args.source}")
    oad.generate_inputs(args.config, args.source, overwrite=True)

    # 2. Risolvi (MDA) oppure ottimizza (MDO)
    if args.mda:
        print("Esecuzione MDA (sola analisi)...")
        problem = oad.evaluate_problem(args.config, overwrite=True)
    else:
        print("Esecuzione MDO (ottimizzazione SLSQP)...")
        problem = oad.optimize_problem(args.config, overwrite=True)

    output_file = problem.output_file_path
    print_summary(output_file)
    return 0


if __name__ == "__main__":
    sys.exit(main())
