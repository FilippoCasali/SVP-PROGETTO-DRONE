#!/usr/bin/env python
"""
(a) Diagnostica a 350 km/h HARD: dash:speed fissa a 350, si cerca un progetto feasible
    (max payload). Riporta se e' feasible, il beta scelto (dovrebbe salire), e i vincoli
    enforced ancora violati.
(b) Frontiera velocita' <-> autonomia: per ogni autonomia T, BISEZIONE su V_dash per
    trovare la massima velocita' garantita (esiste progetto feasible).

Feasibility valutata SOLO sui vincoli enforced (letti da multirotor_exp.yaml), con bound
bilaterali. dash:speed e cruise:speed sono input fissi (li setta questo driver).

Uso: python frontier.py
"""
import sys, subprocess, re
import os.path as pth
import numpy as np
import fastoad.api as oad

HERE = pth.dirname(pth.abspath(__file__))
PY = sys.executable
CONFIG = pth.join(HERE, "multirotor_exp.yaml")
SETREQ = pth.join(HERE, "set_requirements.py")
SOURCE = pth.join(HERE, "problem_inputs.xml")
WORKDIR_IN = pth.join(HERE, "workdir", "problem_inputs.xml")
OUT = pth.join(HERE, "workdir", "problem_outputs.xml")

CEIL = 2000          # quota di lavoro (m)
CRUISE_MS = 41.667   # crociera fissa 150 km/h
TOLC = 1e-3          # tolleranza vincolo

# variabili di dimensionamento da campionare (NO dash/cruise speed; SI payload+beta)
DVS = [
    ("optimization:variables:propulsion:multirotor:propeller:beta", 0.6, 1.4, False),
    ("optimization:variables:propulsion:multirotor:propeller:ND:k", 0.3, 1.0, False),
    ("optimization:variables:propulsion:multirotor:dash:throttle", 0.4, 1.0, False),
    ("optimization:variables:propulsion:multirotor:motor:torque:k", 1.5, 12.0, True),
    ("optimization:variables:propulsion:multirotor:motor:speed:k", 0.5, 5.0, True),
    ("optimization:variables:propulsion:multirotor:battery:voltage:k", 2.0, 9.0, True),
    ("optimization:variables:propulsion:multirotor:esc:power:k", 1.5, 12.0, True),
    ("optimization:variables:geometry:body:diameter", 0.08, 0.25, False),
]


def enforced_bounds():
    """{nome_vincolo: (lower, upper)} dai vincoli DICHIARATI in CONFIG."""
    txt = open(CONFIG).read()
    block = txt.split("\n    constraints:", 1)[1].split("\n    objective:", 1)[0]
    res, cur = {}, None
    for line in block.splitlines():
        s = line.strip()
        m = re.match(r"- name:\s*([^#]+)", s)
        if m:
            cur = m.group(1).strip(); res[cur] = [None, None]
        elif cur and s.startswith("lower:"):
            res[cur][0] = float(s.split(":", 1)[1].split("#")[0])
        elif cur and s.startswith("upper:"):
            res[cur][1] = float(s.split(":", 1)[1].split("#")[0])
    return res


ENF = None


def worst_enforced(d):
    """violazione peggiore sui SOLI vincoli enforced (con bound bilaterali)."""
    worst = 0.0
    for name, (lo, hi) in ENF.items():
        if name not in d:
            continue
        v = d[name]
        if lo is not None:
            worst = min(worst, v - lo)
        if hi is not None:
            worst = min(worst, hi - v)
    return worst


def sample(rng, i):
    vals = {}
    for name, lo, hi, log in DVS:
        u = 0.5 if i == 0 else rng.random()
        vals[name] = float(np.exp(np.log(lo) + u * (np.log(hi) - np.log(lo)))) if log \
            else float(lo + u * (hi - lo))
    return vals


def test(V_ms, N, rng):
    """Feasibility a dash:speed=V_ms (cruise fisso). Ritorna (feasible, worst, payload, beta, viol_dict)."""
    best = None
    for i in range(N):
        oad.generate_inputs(CONFIG, SOURCE, overwrite=True)
        df = oad.DataFile(WORKDIR_IN)
        nn = {v.name: v for v in df}
        nn["mission:sizing:dash:speed:multirotor"].value = [V_ms]
        nn["mission:sizing:main_route:cruise:speed:multirotor"].value = [CRUISE_MS]
        for name, val in sample(rng, i).items():
            if name in nn:
                nn[name].value = [val]
        df.save()
        try:
            oad.optimize_problem(CONFIG, overwrite=True)
        except Exception:
            continue
        d = {v.name: float(np.ravel(v.value)[0]) for v in oad.DataFile(OUT)}
        w = worst_enforced(d)
        pay = d.get("mission:sizing:payload:mass", float("nan"))
        beta = d.get("data:propulsion:multirotor:propeller:beta", float("nan"))
        feas = w >= -TOLC
        score = (feas, pay if feas else w)
        if best is None or score > best[0]:
            viol = {k: d[k] for k in ENF if k in d and worst_enforced_single(d, k) < -TOLC}
            best = (score, w, pay, beta, viol)
    return best


def worst_enforced_single(d, name):
    lo, hi = ENF[name]; v = d[name]; m = 0.0
    if lo is not None: m = min(m, v - lo)
    if hi is not None: m = min(m, hi - v)
    return m


def setreq(endurance):
    subprocess.run([PY, SETREQ, "1.0", str(CEIL), "85", str(endurance)],
                   cwd=HERE, capture_output=True)


def main():
    global ENF
    ENF = enforced_bounds()
    rng = np.random.default_rng(0)

    # ---------- (a) diagnostica 350 hard ----------
    print("=== (a) DIAGNOSTICA 350 km/h HARD (quota %d m, 15 min) ===" % CEIL)
    setreq(15)
    b = test(350 / 3.6, 8, rng)
    if b:
        _, w, pay, beta, viol = b
        print(f"  feasible={w >= -TOLC}  worst={w:+.3f}  payload={pay:.2f}  BETA={beta:.2f}")
        print("  vincoli enforced ancora violati:")
        for k, v in sorted(viol.items(), key=lambda x: x[1])[:6]:
            print(f"    {k.split('constraints:')[-1]:<42}{v:+.3f}")

    # ---------- (b) frontiera velocita' <-> autonomia ----------
    print("\n=== (b) FRONTIERA V_dash max vs AUTONOMIA (quota %d m) ===" % CEIL)
    print(f"  {'autonomia':>10}{'V_dash max':>12}")
    for T in [15, 8, 3]:
        setreq(T)
        lo, hi = 100 / 3.6, 400 / 3.6   # bracket in m/s
        # verifica che lo sia feasible
        b_lo = test(lo, 4, rng)
        if not (b_lo and b_lo[0][0]):
            print(f"  {T:>8} min   < 100 km/h (infeasible anche a bassa V)")
            continue
        for _ in range(5):              # ~5 passi -> tol ~10 km/h
            mid = 0.5 * (lo + hi)
            b = test(mid, 4, rng)
            if b and b[0][0]:
                lo = mid
            else:
                hi = mid
        print(f"  {T:>8} min   {lo * 3.6:6.0f} km/h")


if __name__ == "__main__":
    main()
