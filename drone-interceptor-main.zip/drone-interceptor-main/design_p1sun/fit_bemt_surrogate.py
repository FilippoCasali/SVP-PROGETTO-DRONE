#!/usr/bin/env python
"""
Rifit dei coefficienti del surrogato assiale di FAST-UAV usando il BEMT come verita'.

Mantiene ESATTAMENTE la forma funzionale di aero_coefficients_axial:
    c = m[0] + m[1]*b + m[2]*b^2 + m[3]*b^3 + m[4]*J + m[5]*J^2 + m[6]*J^3
        + m[7]*b*J + m[8]*b^2*J + m[9]*b*J^2
piu' i due coefficienti dell'advance ratio a spinta/potenza nulla: J0 = m[-2] + m[-1]*b.
E la forma statica: c_static = s[0] + s[1]*b.

Salva bemt_coeffs.npz (dinamico) e bemt_static.npz (statico). set_requirements.py li
carica e li scrive negli input, quindi il rifit si propaga al design senza copia-incolla.

[2b] Novita' rispetto alla versione precedente:
  - chord_to_radius ALLINEATO a 0.15 (stesso valore del modello d'incidenza in
    physics/propeller.py: prima il BEMT usava 0.225 -> solidita' incoerente).
  - griglia estesa ad alto passo (beta 0.3-1.8) e alto avanzamento (J 0-2.5), piu' densa.
  - report RMS globale E nel corner del dash (beta 1.2-1.4, J 1.0-1.5).
"""
import numpy as np
from bemt import bemt_axial

CHORD_TO_RADIUS = 0.15   # allineato al modello d'incidenza (Leng 2019) in src/


def design_matrix(b, J):
    return np.column_stack([
        np.ones_like(b), b, b**2, b**3,
        J, J**2, J**3,
        b*J, b**2*J, b*J**2,
    ])


def main():
    betas = np.linspace(0.3, 1.8, 31)   # alto passo per il dash
    Js = np.linspace(0.0, 2.5, 76)      # alto avanzamento, piu' denso
    B, JJ, CT, CP = [], [], [], []
    j0t_pts, j0p_pts, beta_pts = [], [], []
    ct0_pts, cp0_pts = [], []           # statici (J=0)
    for b in betas:
        ct_prev = cp_prev = None
        j0t = j0p = None
        for k, j in enumerate(Js):
            ct, cp = bemt_axial(b, j, chord_to_radius=CHORD_TO_RADIUS)
            if k == 0:
                ct0_pts.append(ct); cp0_pts.append(cp)   # punto statico
            # campiona solo dove il modello produce spinta/potenza (zona fisica)
            if ct > 1e-4:
                B.append(b); JJ.append(j); CT.append(ct); CP.append(cp)
            # advance ratio di spinta/potenza nulla (prima transizione a ~0)
            if j0t is None and ct_prev is not None and ct_prev > 1e-4 and ct <= 1e-4:
                j0t = j
            if j0p is None and cp_prev is not None and cp_prev > 1e-4 and cp <= 1e-4:
                j0p = j
            ct_prev, cp_prev = ct, cp
        beta_pts.append(b)
        j0t_pts.append(j0t if j0t is not None else Js[-1])
        j0p_pts.append(j0p if j0p is not None else Js[-1])

    B = np.array(B); JJ = np.array(JJ); CT = np.array(CT); CP = np.array(CP)
    A = design_matrix(B, JJ)
    ct_coef, *_ = np.linalg.lstsq(A, CT, rcond=None)
    cp_coef, *_ = np.linalg.lstsq(A, CP, rcond=None)

    # J0(beta) = p0 + p1*beta  (retta ai minimi quadrati)
    bp = np.array(beta_pts)
    j0t_lin = np.polyfit(bp, np.array(j0t_pts), 1)  # [slope, intercept]
    j0p_lin = np.polyfit(bp, np.array(j0p_pts), 1)
    ct_full = np.concatenate([ct_coef, [j0t_lin[1], j0t_lin[0]]])
    cp_full = np.concatenate([cp_coef, [j0p_lin[1], j0p_lin[0]]])

    # statico: c_static = s0 + s1*beta
    ct_stat = np.polyfit(bp, np.array(ct0_pts), 1)[::-1]  # [s0, s1]
    cp_stat = np.polyfit(bp, np.array(cp0_pts), 1)[::-1]

    # qualita' del fit: globale e nel corner del dash
    ct_pred = A @ ct_coef; cp_pred = A @ cp_coef
    rms_ct = np.sqrt(np.mean((ct_pred-CT)**2)); rms_cp = np.sqrt(np.mean((cp_pred-CP)**2))
    corner = (B >= 1.2) & (JJ >= 1.0) & (JJ <= 1.5)
    if corner.any():
        rms_ct_c = np.sqrt(np.mean((ct_pred[corner]-CT[corner])**2))
        rms_cp_c = np.sqrt(np.mean((cp_pred[corner]-CP[corner])**2))
    else:
        rms_ct_c = rms_cp_c = float('nan')

    print(f"# Fit su {len(CT)} punti BEMT (beta 0.3-1.8, J 0-2.5, chord/R={CHORD_TO_RADIUS})")
    print(f"# RMS globale : Ct {rms_ct:.4f}  Cp {rms_cp:.4f}")
    print(f"# RMS dash-corner (beta>=1.2, J 1.0-1.5): Ct {rms_ct_c:.4f}  Cp {rms_cp_c:.4f}")
    print(f"# J0t(beta) ~ {j0t_lin[1]:.3f} + {j0t_lin[0]:.3f}*beta")
    print(f"# J0p(beta) ~ {j0p_lin[1]:.3f} + {j0p_lin[0]:.3f}*beta")
    print(f"# static Ct ~ {ct_stat[0]:.4f} + {ct_stat[1]:.4f}*beta ; Cp ~ {cp_stat[0]:.4f} + {cp_stat[1]:.4f}*beta\n")
    np.set_printoptions(precision=6, suppress=True)
    print("CT_MODEL_BEMT =", np.array2string(ct_full, separator=", "))
    print("CP_MODEL_BEMT =", np.array2string(cp_full, separator=", "))

    np.savez("bemt_coeffs.npz", ct=ct_full, cp=cp_full)
    np.savez("bemt_static.npz", ct=ct_stat, cp=cp_stat)


if __name__ == "__main__":
    main()
