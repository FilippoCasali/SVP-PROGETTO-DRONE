#!/usr/bin/env python
"""
Multi-start per il P1-SUN: campiona N punti di partenza casuali nei bound delle
design variables, ottimizza da ciascuno con SLSQP, e tiene il MIGLIORE feasible.

Serve perche' con la nuova fisica (compressibilita' elica) il problema e' rugoso e
SLSQP dipende molto dal punto iniziale. Il multi-start esplora e trova un ottimo
convergente pulito senza warm-start manuale.

Uso:
    python run_multistart.py [N]        # N tentativi (default 12)
"""
import sys
import shutil
import os.path as pth
import numpy as np
import fastoad.api as oad

HERE = pth.dirname(pth.abspath(__file__))
CONFIG = pth.join(HERE, "multirotor_mdo.yaml")
SOURCE = pth.join(HERE, "problem_inputs.xml")
WORKDIR_IN = pth.join(HERE, "workdir", "problem_inputs.xml")
OUT = pth.join(HERE, "workdir", "problem_outputs.xml")

N = int(sys.argv[1]) if len(sys.argv) > 1 else 12
SEED = 0  # riproducibile (no Date/random di sistema)

# Design variables campionabili: (nome, low, high, scala log?)
DVS = [
    ("optimization:variables:weight:mtow:k", 1.0, 20.0, True),
    ("optimization:variables:propulsion:multirotor:battery:energy:k", 1.0, 18.0, True),
    ("optimization:variables:propulsion:multirotor:propeller:beta", 0.6, 1.4, False),
    ("optimization:variables:propulsion:multirotor:propeller:ND:k", 0.3, 1.0, False),
    ("optimization:variables:propulsion:multirotor:dash:throttle", 0.4, 1.0, False),
    ("optimization:variables:propulsion:multirotor:motor:torque:k", 1.5, 12.0, True),
    ("optimization:variables:propulsion:multirotor:motor:speed:k", 0.5, 5.0, True),
    ("optimization:variables:propulsion:multirotor:battery:voltage:k", 2.0, 9.0, True),
    ("optimization:variables:propulsion:multirotor:esc:power:k", 1.5, 12.0, True),
    ("optimization:variables:geometry:body:diameter", 0.08, 0.25, False),
    # [Modo A] driver = velocita' di intercettazione; crociera libera. Payload fisso (no DV).
    ("mission:sizing:dash:speed:multirotor", 41.7, 111.1, False),
    ("mission:sizing:main_route:cruise:speed:multirotor", 41.7, 111.1, False),
]

CONSTRAINT_PREFIX = "optimization:constraints"


def sample(rng, i):
    """Punto i: primo = medio, poi random nei bound.
    Ω_dash e beta inizializzati ALTI: evita che il dash parta in windmilling
    (giri troppo bassi -> J>J0 -> spinta 0), la trappola che rompe il dash."""
    vals = {}
    for name, lo, hi, log in DVS:
        if i == 0:
            u = 0.5
        elif "propeller:beta" in name:
            u = 0.4 + 0.6 * rng.random()      # beta medio-alto (compressibilita' penalizza giri)
        else:
            u = rng.random()
        if log:
            vals[name] = float(np.exp(np.log(lo) + u * (np.log(hi) - np.log(lo))))
        else:
            vals[name] = float(lo + u * (hi - lo))
    return vals


def feasible_and_payload(xml):
    df = oad.DataFile(xml)
    n = {v.name: v for v in df}
    worst = 0.0
    for v in df:
        if v.name.startswith(CONSTRAINT_PREFIX):
            val = float(np.ravel(v.value)[0])
            worst = min(worst, val)
    # [Modo A] la metrica di merito e' la velocita' di intercettazione [km/h]
    vdash = float(np.ravel(n["mission:sizing:dash:speed:multirotor"].value)[0]) * 3.6
    mtow = float(np.ravel(n["data:weight:mtow"].value)[0])
    return worst, vdash, mtow


def main():
    rng = np.random.default_rng(SEED)
    best = None
    print(f"Multi-start: {N} tentativi\n")
    print(f"  {'#':>3} {'esito':<10}{'max viol':>10}{'Vdash kmh':>11}{'MTOW':>7}")
    for i in range(N):
        # genera input dal source, poi sovrascrivi i punti iniziali
        oad.generate_inputs(CONFIG, SOURCE, overwrite=True)
        df = oad.DataFile(WORKDIR_IN)
        nn = {v.name: v for v in df}
        for name, val in sample(rng, i).items():
            if name in nn:
                nn[name].value = [val]
        df.save()
        try:
            oad.optimize_problem(CONFIG, overwrite=True)
            worst, vdash, mtow = feasible_and_payload(OUT)
        except Exception as e:
            print(f"  {i:>3} {'errore':<10}  {str(e)[:40]}")
            continue
        feas = worst >= -1e-3
        tag = "FEASIBLE" if feas else "infeas"
        print(f"  {i:>3} {tag:<10}{worst:>10.3f}{vdash:>11.1f}{mtow:>7.2f}")
        # [Modo A] tieni il migliore: feasible con V_dash massima; a parità, meno violazione
        score = (feas, vdash if feas else worst)
        if best is None or score > best[0]:
            best = (score, vdash, mtow, worst)
            shutil.copy(OUT, pth.join(HERE, "workdir", "best_multistart.xml"))

    print("\n" + "=" * 40)
    if best and best[0][0]:
        print(f"  MIGLIORE FEASIBLE: V_dash {best[1]:.1f} km/h, MTOW {best[2]:.2f} kg")
    elif best:
        print(f"  Nessun feasible. Migliore: viol {best[3]:.3f}, V_dash {best[1]:.1f} km/h")
    print("=" * 40)


if __name__ == "__main__":
    main()
