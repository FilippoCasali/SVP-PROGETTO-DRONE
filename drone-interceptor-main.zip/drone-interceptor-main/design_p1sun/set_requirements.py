#!/usr/bin/env python
"""
Definizione dei REQUISITI P1-SUN + MARGINE settabile, e scrittura negli input.

Separa i requisiti (qui) dal tuning dell'ottimizzatore (nel .yaml). Un unico fattore
MARGIN gonfia i requisiti di PRESTAZIONE per coprire le incertezze del modello:
  MARGIN = 1.00  -> progetto esattamente a capitolato
  MARGIN = 1.10  -> progetto al 110% di ogni requisito di prestazione (conservativo)

Scrive tutti i valori sia in workdir/problem_inputs.xml sia nel source problem_inputs.xml
(cosi' run_design.py, che rigenera dal source, trova tutte le variabili).

Uso:
    python set_requirements.py            # applica con MARGIN corrente
    python set_requirements.py 1.1        # applica con MARGIN = 1.1
"""
import sys, shutil
import os.path as pth
import fastoad.api as oad

HERE = pth.dirname(pth.abspath(__file__))
CONFIG = pth.join(HERE, "multirotor_mdo.yaml")
SOURCE = pth.join(HERE, "problem_inputs.xml")
WORKDIR_IN = pth.join(HERE, "workdir", "problem_inputs.xml")

# ============================ MARGINE ============================
MARGIN = float(sys.argv[1]) if len(sys.argv) > 1 else 1.00   # <<< settabile

# ===================== REQUISITI (capitolato) ====================
VMAX_KMH       = 350.0    # velocita' max orizzontale [km/h]        (margine)
CLIMB_RATE     = 35.0     # rateo salita verticale [m/s]            (margine)
# quota operativa [m] (margine) — override opzionale da argv[2] per ricerca di feasibility
CEILING_M      = float(sys.argv[2]) if len(sys.argv) > 2 else 6000.0
ENDURANCE_MIN  = float(sys.argv[4]) if len(sys.argv) > 4 else 15.0   # autonomia [min] (override argv[4] per Modo B)
DASH_FRACTION  = 0.10     # frazione minima a Vmax
PAYLOAD_MIN    = 0.5      # payload minimo [kg]  (obiettivo: massimizzare)
MTOW_MAX       = 6.0      # MTOW massimo [kg]    (vincolo hard)

# ============ PARAMETRI DI MISSIONE (scelte, non margine) ========
CRUISE_KMH     = 150.0    # crociera lenta [km/h] (requisito: >150)
CLIMB_SPEED    = 50.0     # airspeed in salita [m/s] -> angolo ~44 gradi
MISC_MASS      = 0.35     # avionica + computer visual imaging [kg]
N_PROPELLERS   = 4.0
TW_RATIO       = 5.0     # spinta max al decollo = 5x peso (intercettore aggressivo)
CD0            = 0.15
# limite ND (= n*D, NON velocita' di punta!). Il vincolo usa W*D/(2pi)=n*D, e la punta
# reale e' V_tip = pi*ND. Quindi ND_MAX=85 => V_tip <= pi*85 ~= 266 m/s ~= Mach 0.80 a 2000 m
# (coerente col cap del dash). Prima era 220 -> permetteva V_tip=pi*220~=691 m/s (Mach ~2), sbagliato.
# override da argv[3] per esperimenti sul limite di punta.
ND_MAX         = float(sys.argv[3]) if len(sys.argv) > 3 else 85.0

# ---- applica il margine ai requisiti di prestazione ----
vmax   = VMAX_KMH * MARGIN
climb  = CLIMB_RATE * MARGIN
ceil_m = CEILING_M * MARGIN
endur  = ENDURANCE_MIN * MARGIN

# ---- costruisce il profilo di missione: CRUISE-CLIMB graduale + dash ----
# Invece di "salita ripida a quota max + crociera piatta in quota", il tratto principale
# e' una salita DOLCE alla velocita' di crociera che raggiunge il ceiling nell'arco di tutta
# l'autonomia utile. La potenza e' valutata a quota MEDIA -> aria piu' densa -> meno energia
# (guadagno tanto maggiore quanto piu' alto e' il ceiling).
vmax_ms   = vmax / 3.6
cruise_ms = CRUISE_KMH / 3.6
t_dash    = DASH_FRACTION * endur * 60.0        # [s] dash (>=10% dell'autonomia)
t_main    = endur * 60.0 - t_dash               # [s] tutto il resto = cruise-climb
if t_main <= 0:
    raise SystemExit(f"MARGIN {MARGIN} troppo alto: tempo cruise-climb negativo")
climb_rate = ceil_m / t_main                    # [m/s] rateo dolce: ceiling raggiunto in t_main
d_main  = cruise_ms * t_main                    # [m] distanza orizzontale del cruise-climb
d_dash  = vmax_ms * t_dash

print(f"MARGIN = {MARGIN}")
print(f"  Vmax {vmax:.0f} km/h | quota {ceil_m:.0f} m | autonomia {endur:.1f} min")
print(f"  Profilo CRUISE-CLIMB: salita dolce {climb_rate:.1f} m/s per {t_main/60:.2f}min "
      f"({d_main/1000:.1f}km, 0->{ceil_m:.0f}m, quota media {ceil_m/2:.0f}m) | dash {t_dash/60:.2f}min ({d_dash/1000:.1f}km)")

# ---- scrive negli input (workdir template completo -> source) ----
oad.generate_inputs(CONFIG, SOURCE, overwrite=True)   # template con tutte le variabili
df = oad.DataFile(WORKDIR_IN)
n = {v.name: v for v in df}
def setv(k, val):
    if k in n:
        n[k].value = [val]
    else:
        print(f"  ! assente: {k}")

setv("mission:sizing:payload:mass", PAYLOAD_MIN)
setv("data:weight:misc:mass", MISC_MASS)
setv("data:weight:mtow:requirement", MTOW_MAX)
setv("data:propulsion:multirotor:propeller:number", N_PROPELLERS)
setv("mission:sizing:thrust_weight_ratio:multirotor", TW_RATIO)
setv("data:aerodynamics:multirotor:CD0", CD0)
setv("models:propulsion:multirotor:propeller:ND:max:reference", ND_MAX)
# geometria corpo (fusoliera snella: L fissa, d variabile)
setv("data:geometry:body:length", 0.600)              # lunghezza fissa = max
setv("data:geometry:body:fill_factor", 0.65)          # riempimento interno
setv("data:geometry:body:volume:payload", 400e-6)     # >=400 cm3 (requisito)
setv("data:geometry:body:volume:avionics", 200e-6)    # avionica+compute
setv("optimization:variables:geometry:body:diameter", 0.12)  # init
# cruise-climb (main_route): salita dolce a velocita' di crociera da 0 al ceiling
setv("mission:sizing:main_route:climb:rate:multirotor", climb_rate)   # rateo dolce
setv("mission:sizing:main_route:climb:speed:multirotor", cruise_ms)   # a velocita' di crociera
setv("mission:sizing:main_route:takeoff:altitude", 0.0)
setv("mission:sizing:main_route:cruise:altitude", ceil_m)             # quota di arrivo (=ceiling)
setv("mission:sizing:main_route:cruise:speed:multirotor", cruise_ms)
# niente crociera piatta in quota: il cruise-climb porta tutta l'energia (cruise flat ~0)
setv("mission:sizing:main_route:cruise:distance", 0.0)
# dash (dash_route) — la velocita' del tratto dash e' mission:sizing:dash:speed (Modo A),
# letta direttamente dal leg dash: qui bastano quota e distanza.
setv("mission:sizing:dash_route:cruise:altitude", ceil_m)
setv("mission:sizing:dash_route:cruise:distance", d_dash)
# vincolo dash (reachability) a Vmax
setv("mission:sizing:dash:speed:multirotor", vmax_ms)

# --- coefficienti surrogato BEMT rifittati (dinamico + statico) dai npz ---
# Cosi' il rifit di fit_bemt_surrogate.py si propaga al design senza copia-incolla.
import numpy as _np
def setarr(k, arr):
    if k in n:
        n[k].value = [float(x) for x in _np.ravel(arr)]
    else:
        print(f"  ! assente: {k}")
try:
    _dyn = _np.load(pth.join(HERE, "bemt_coeffs.npz"))
    _stat = _np.load(pth.join(HERE, "bemt_static.npz"))
    setarr("models:propulsion:multirotor:propeller:Ct:dynamic:polynomial", _dyn["ct"])
    setarr("models:propulsion:multirotor:propeller:Cp:dynamic:polynomial", _dyn["cp"])
    setarr("models:propulsion:multirotor:propeller:Ct:static:polynomial", _stat["ct"])
    setarr("models:propulsion:multirotor:propeller:Cp:static:polynomial", _stat["cp"])
    print("  surrogato BEMT (npz) caricato negli input")
except FileNotFoundError:
    print("  ! bemt_coeffs/static.npz non trovati: uso i coeff gia' presenti nel source")

df.save()
shutil.copy(WORKDIR_IN, SOURCE)
print("Requisiti scritti (workdir + source).")
