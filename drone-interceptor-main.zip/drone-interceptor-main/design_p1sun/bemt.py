#!/usr/bin/env python
"""
BEMT (Blade Element Momentum Theory) hover-capable per i coefficienti assiali Ct(J), Cp(J).

Formulazione a VELOCITA' INDOTTA ASSOLUTA (vi, non a*V): resta valida a punto fisso (J=0),
dove la formulazione classica a fattori di induzione degenera. Include tip-loss di Prandtl
e polare con stallo. Pensato per sostituire aero_coefficients_axial() di FAST-UAV.

Convenzione coefficienti (identica a FAST-UAV, n in giri/s):
    Ct = T / (rho * n^2 * D^4),   Cp = P / (rho * n^3 * D^5),   J = V / (n*D)
"""
import numpy as np


def _polar(alpha, a0, alpha0, cl_max, cd0, k_cd):
    """
    Polare di sezione LISCIA (C-infinito) per gradienti puliti nell'ottimizzatore.
    - Cl: saturazione dolce con tanh (linea a0 vicino a 0, plateau a cl_max in stallo)
    - Cd: polare quadratica + termine post-stallo continuo (~sin^2)
    """
    cl_lin = a0 * (alpha - alpha0)
    cl = cl_max * np.tanh(cl_lin / cl_max)          # saturazione morbida, monotona
    # frazione di stallo continua in [0,1] (transizione dolce attorno a cl_max)
    stall_frac = np.tanh((np.abs(cl_lin) / cl_max - 1.0).clip(min=0.0) * 3.0)
    cd = cd0 + k_cd * cl**2 + stall_frac * 1.2 * np.sin(alpha) ** 2
    return cl, cd


def bemt_axial(beta, J, n_blades=2, chord_to_radius=0.225, n_elem=60,
               a0=5.8, alpha0_deg=-2.0, cd0=0.008, k_cd=0.04,
               cl_max=1.3, root_cut=0.15, max_iter=200, tol=1e-7):
    """
    Ct, Cp assiali via BEMT (velocita' indotta assoluta).

    beta            : pitch-to-diameter ratio p/D (elica a passo geometrico costante)
    J               : advance ratio V/(nD)  (J=0 -> hover, gestito)
    n_blades        : numero di pale
    chord_to_radius : corda/raggio (costante lungo l'apertura)
    a0              : pendenza Cl-alpha (1/rad)
    alpha0_deg      : angolo di portanza nulla (gradi)
    cd0, k_cd       : polare Cd = cd0 + k_cd*Cl^2
    cl_max          : Cl di stallo
    root_cut        : frazione di raggio non portante alla radice
    """
    R = 0.5
    D = 2 * R
    n_rps = 1.0
    Omega = 2 * np.pi * n_rps
    V = J * n_rps * D                       # = J

    x = np.linspace(root_cut, 1.0, n_elem)  # r/R
    r = x * R
    c = chord_to_radius * R                  # corda costante
    theta = np.arctan(beta / (np.pi * x))    # calettamento a passo costante
    alpha0 = np.deg2rad(alpha0_deg)
    rho = 1.0

    dT = np.zeros(n_elem)
    dQ = np.zeros(n_elem)
    for i in range(n_elem):
        vi = 0.05 * Omega * r[i]             # innesco velocita' indotta assiale
        ap = 0.0                             # fattore induzione tangenziale
        for _ in range(max_iter):
            Ua = V + vi
            Ut = Omega * r[i] * (1 - ap)
            W2 = Ua**2 + Ut**2
            phi = np.arctan2(Ua, Ut)
            alpha = theta[i] - phi
            cl, cd = _polar(alpha, a0, alpha0, cl_max, cd0, k_cd)
            cphi, sphi = np.cos(phi), np.sin(phi)
            Cn = cl * cphi - cd * sphi
            Ctan = cl * sphi + cd * cphi
            # tip loss di Prandtl
            arg = n_blades / 2 * (1 - x[i]) / max(x[i] * sphi, 1e-6)
            F = max(2 / np.pi * np.arccos(np.exp(-min(arg, 30))), 1e-4)
            # bilancio quantita' di moto (velocita' indotta assoluta)
            #  BE:  dT/dr = 0.5*rho*B*c*W2*Cn
            #  MOM: dT/dr = 4*pi*r*rho*Ua*vi*F   ->   vi = BE/(4*pi*r*Ua*F)
            be_T = 0.5 * rho * n_blades * c * W2 * Cn
            vi_new = be_T / (4 * np.pi * r[i] * max(Ua, 1e-6) * F * rho)
            #  swirl: dQ/dr = 0.5*rho*B*c*W2*Ctan*r = 4*pi*r^3*rho*Ua*Omega*ap*F
            be_Q = 0.5 * rho * n_blades * c * W2 * Ctan * r[i]
            ap_new = be_Q / (4 * np.pi * r[i]**3 * max(Ua, 1e-6) * Omega * F * rho + 1e-12)
            vi_new = np.clip(vi_new, -0.5 * Omega * R, 1.5 * Omega * R)
            ap_new = np.clip(ap_new, -0.5, 0.9)
            if abs(vi_new - vi) < tol * Omega * R and abs(ap_new - ap) < tol:
                vi, ap = vi_new, ap_new
                break
            vi = 0.6 * vi + 0.4 * vi_new     # rilassamento
            ap = 0.6 * ap + 0.4 * ap_new
        Ua = V + vi
        Ut = Omega * r[i] * (1 - ap)
        W2 = Ua**2 + Ut**2
        phi = np.arctan2(Ua, Ut)
        alpha = theta[i] - phi
        cl, cd = _polar(alpha, a0, alpha0, cl_max, cd0, k_cd)
        cphi, sphi = np.cos(phi), np.sin(phi)
        dT[i] = 0.5 * rho * n_blades * c * W2 * (cl * cphi - cd * sphi)
        dQ[i] = 0.5 * rho * n_blades * c * W2 * (cl * sphi + cd * cphi) * r[i]

    T = np.trapezoid(dT, r)
    Q = np.trapezoid(dQ, r)
    P = Omega * Q
    Ct = T / (n_rps**2 * D**4)
    Cp = P / (n_rps**3 * D**5)
    return max(1e-10, Ct), max(1e-10, Cp)


if __name__ == "__main__":
    for beta in (0.5, 0.7, 0.9):
        print(f"beta={beta}")
        for J in (0.0, 0.2, 0.4, 0.6, 0.8, 1.0, 1.2, 1.4):
            ct, cp = bemt_axial(beta, J)
            print(f"  J={J:.2f}  Ct={ct:.4f}  Cp={cp:.4f}")
