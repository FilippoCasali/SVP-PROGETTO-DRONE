# Modello di batteria — documentazione (multifisica a fedelta' selezionabile)

Documento di riferimento del modello di batteria in FAST-UAV dopo l'introduzione del
livello elettrico ECM. Descrive i livelli disponibili, come selezionarli, le equazioni,
gli input/output, la retro-compatibilita' e i limiti. Lo stato riflette il codice
implementato e verificato.

---

## 1. Livelli di fedelta' e come selezionarli

Il gruppo batteria (`fastuav.propulsion.battery`) espone l'opzione **`fidelity`**,
propagata dal modulo propulsione tramite `battery_fidelity`:

| Valore | Descrizione |
|---|---|
| `L0_scaling` (default) | Modello originale: riscalatura lineare energia/massa da un componente di riferimento, tensione come variabile continua. |
| `L1_ecm` | Aggiunge il modello elettrico a celle: resistenza interna del pacco (sag di tensione), numero di celle, corrente massima da C-rate, vincolo di C-rate. |

In parallelo, una **penalita' Ragone** (massa che cresce col C-rate richiesto) e'
disponibile come parametro indipendente dalla fedelta' (default disattivato).

Configurazione:

```yaml
    propulsion:
        id: fastuav.propulsion.multirotor
        battery_fidelity: L1_ecm      # oppure L0_scaling (default)
```

**Retro-compatibilita' (verificata numericamente):**
- con `L0_scaling` l'ECM non viene istanziato -> comportamento originale;
- anche con `L1_ecm`, i parametri nuovi hanno default neutri: `R_pack` entra nel modulo
  dash con default 0 (sag nullo) e `ragone:coefficient` ha default 0 (massa = formula
  originale). Chi non li imposta ottiene esattamente il modello precedente.

---

## 2. Livello L0 — riscalatura (invariato)

Dal componente di riferimento (DJI M600): E_ref=468 kJ, U_ref=22.8 V, I_ref=200 A,
m_ref=0.68 kg.

```
E_bat    = E_ref * P_max / (U_ref * I_ref)      [kJ]   energia (scala con potenza)
C_bat    = E_bat / U_bat                        [A*s]  capacita' (relazione fisica E=C*U)
I_bat_max= I_ref * C_bat / C_ref                [A]    corrente max (scalata)
m_bat    = m_ref * E_bat / E_ref                [kg]   massa (lineare con energia)
Vol_bat  = Vol_ref * (...)                       [cm3]  volume (scalato)
```

Tensione U_bat: variabile di progetto (via `voltage:k`). Limiti di tensione da regressione
statistica sul database (`U_max = 0.61*P^0.40 + 16.24`).

**Limiti L0:** nessun sag, nessuna resistenza interna, nessun C-rate dinamico, nessun
modello a celle; il peso tende a essere sottostimato e la velocita' massima sovrastimata
(giri calcolati a tensione nominale, senza caduta sotto carico).

---

## 3. Livello L1 — ECM a celle

Componente `BatteryElectricalModel`: dal pacco gia' dimensionato e da una CELLA di
riferimento ricava numero celle, resistenza interna, corrente massima e il vincolo di
C-rate.

### 3.1 Architettura del pacco
```
Ns = max(1, V_pack / V_cell_nom)      celle in serie   (floor fisico >= 1)
Np = max(1, Q_pack / Q_cell)          celle in parallelo (floor fisico >= 1)
R_pack = (Ns / Np) * r_cell           [ohm]  resistenza interna del pacco
I_max_crate = Cmax_cell * (Q_pack/3600)   [A]   corrente massima di scarica
Crate_req  = (P_max/V_pack) / (Q_pack/3600)  [1/h]  C-rate effettivamente richiesto
```

Il floor `>= 1` evita frazioni di cella non fisiche durante l'ottimizzazione continua
(Ns, Np restano continui e vanno arrotondati a valle).

### 3.2 Sag di tensione (applicato al dash)
La tensione ai morsetti cala con la corrente:
```
V_load = V_pack - I_batt * R_pack
```
Nel modulo di velocita' massima i giri disponibili al dash diventano:
```
W_dash = throttle * Kv * V_load       (invece di Kv * V_pack)
```
Implementazione predictor-corrector (forma chiusa, liscia): si stima la corrente con la
tensione nominale, si calcola V_load, si ricalcola il punto di funzionamento dell'elica.
Con `R_pack = 0` (default / L0) il risultato coincide esattamente col modello originale
(verificato: W_dash identico).

### 3.3 Vincolo di C-rate
```
g_crate = (I_max_crate - I_peak) / I_max_crate >= 0
```
I_peak: corrente di picco richiesta (proxy: potenza massima / tensione pacco).

Nota di configurazione: il vincolo `battery:crate` va attivato SOLO con `L1_ecm`. In
`L0_scaling` il componente non esiste e il vincolo resterebbe senza sorgente (errore).
Nel file di configurazione e' lasciato commentato con nota.

---

## 4. Penalita' Ragone (massa vs C-rate)

Effetto fisico: celle progettate per erogare alta corrente (alto C-rate) hanno densita'
energetica inferiore, quindi pesano di piu' a parita' di Wh. Implementata nel componente
di massa (`Weight`) come fattore sul risultato di riscalatura:

```
Crate_req = (P_max / V) / (Q / 3600)                 [1/h]
derate    = 1 - k_ragone * min(Crate_req / Cmax, 0.95)
m_bat     = m_bat_base / max(derate, 0.2)
```

Parametro `models:propulsion:battery:ragone:coefficient` (k_ragone):
- **k_ragone = 0 (default)** -> `derate = 1` -> massa = formula originale (nessun effetto);
- k_ragone > 0 -> massa maggiorata in funzione del C-rate richiesto.

Verifica numerica (energia costante): k=0 -> 1.453 kg; k=0.4 -> +12%; k=0.8 -> +28%.

Il parametro e' **ortogonale alla fedelta'**: si puo' usare anche con L0 (e' solo un
raffinamento del modello di massa). Default 0 -> retro-compatibile.

---

## 5. Cella di riferimento e parametri (input)

| Parametro | Variabile | Default | Unita' |
|---|---|---|---|
| Tensione nominale cella | `...cell:voltage:reference` | 3.7 | V |
| Capacita' cella | `...cell:capacity:reference` | 5400 (1.5 Ah) | A*s |
| Resistenza interna cella | `...cell:resistance:reference` | 2.5e-3 | ohm |
| C-rate massimo | `...cell:Crate:max:reference` | 100 | 1/h |
| Coefficiente Ragone | `...ragone:coefficient` | 0.0 | - |

(prefisso `models:propulsion:battery:`). Valori indicativi per LiPo racing;
da confermare rispetto a una cella commerciale specifica.

---

## 6. Output (L1)

- `data:propulsion:battery:resistance` [ohm] — R_pack (letto dal dash per il sag)
- `data:propulsion:battery:current:max:crate` [A]
- `data:propulsion:battery:ecm:Crate:required` [1/h]
- `data:propulsion:battery:ecm:number:series`, `:parallel`
- `optimization:constraints:propulsion:battery:crate`

---

## 7. Stato di verifica (compatibilita')

Controlli eseguiti e superati:

1. Sintassi e import di tutti i file toccati.
2. Nessun ciclo di import reale (il componente ECM dipende solo da numpy/openmdao).
3. Retro-compatibilita' modulo dash: con R_pack=0, i giri al dash coincidono col modello
   originale; con R_pack>0 il sag riduce i giri.
4. Tutti gli output L1 sono connessi nel pool (nessun orfano/NaN).
5. Retro-compatibilita' modulo massa: con ragone=0 la massa e' identica alla formula
   originale.
6. L0 ed L1 girano sia in valutazione (MDA) sia in ottimizzazione (end-to-end).

---

## 8. Limiti dichiarati

- resistenza interna costante (non funzione di stato di carica o temperatura);
- OCV non tracciata durante la missione: il sag e' valutato al picco di corrente, non
  lungo la scarica (estensione possibile con stato di carica per fase);
- il sag e' applicato al punto dimensionante di velocita' massima (dash); i vincoli di
  tensione delle altre fasi usano ancora la tensione nominale (completezza futura);
- nessuna dinamica RC (transitori): non e' un modello Thevenin. La dinamica temporale
  serve alla simulazione runtime, non al dimensionamento statico;
- modello a celle rilassato al continuo (Ns, Np non interi in ottimizzazione: arrotondare
  a valle);
- il componente di massa (`Weight`) usa derivate per differenze finite (le analitiche
  originali, non comprensive del termine Ragone, sono disattivate).

---

## 9. Riferimenti

- "A Parametric Battery Model for the Conceptual Design of Electric Aircraft",
  NASA/AIAA Aviation 2024.
- "Comparison and Application of Battery Modeling Methods", NASA 2024.
- Dati LiPo racing (resistenza interna, C-rate, densita' energetica) da letteratura UAV/FPV.
