#!/usr/bin/env python
"""
Analisi: fra le soluzioni (Modo A) che raggiungono V_dash >= 350 km/h, quali vincoli
sono maggiormente NON rispettati? Rilancia N start casuali, tiene le soluzioni a >=350,
e aggrega la violazione media e la frequenza con cui ogni vincolo e' il PEGGIORE.

Uso: python analyze_350plus.py [N]   (default 16)
"""
import sys
import os.path as pth
from collections import defaultdict
import numpy as np
import fastoad.api as oad

HERE = pth.dirname(pth.abspath(__file__))
CONFIG = pth.join(HERE, "multirotor_mdo.yaml")
SOURCE = pth.join(HERE, "problem_inputs.xml")
WORKDIR_IN = pth.join(HERE, "workdir", "problem_inputs.xml")
OUT = pth.join(HERE, "workdir", "problem_outputs.xml")

N = int(sys.argv[1]) if len(sys.argv) > 1 else 16
V_TARGET = 350.0  # km/h

DVS = [
    ("optimization:variables:propulsion:multirotor:propeller:beta", 0.6, 1.4, False),
    ("optimization:variables:propulsion:multirotor:propeller:ND:k", 0.3, 1.0, False),
    ("optimization:variables:propulsion:multirotor:dash:throttle", 0.4, 1.0, False),
    ("optimization:variables:propulsion:multirotor:motor:torque:k", 1.5, 12.0, True),
    ("optimization:variables:propulsion:multirotor:motor:speed:k", 0.5, 5.0, True),
    ("optimization:variables:propulsion:multirotor:battery:voltage:k", 2.0, 9.0, True),
    ("optimization:variables:propulsion:multirotor:esc:power:k", 1.5, 12.0, True),
    ("optimization:variables:geometry:body:diameter", 0.08, 0.25, False),
    # dash alto per forzare start a >=350; cruise libera
    ("mission:sizing:dash:speed:multirotor", 90.0, 111.1, False),
    ("mission:sizing:main_route:cruise:speed:multirotor", 41.7, 111.1, False),
]


def sample(rng, i):
    vals = {}
    for name, lo, hi, log in DVS:
        if "dash:speed" in name:
            u = 0.5 + 0.5 * rng.random()  # start alto (>=350) per esplorare quel regime
        elif i == 0:
            u = 0.5
        elif "propeller:beta" in name:
            u = 0.4 + 0.6 * rng.random()
        else:
            u = rng.random()
        vals[name] = float(np.exp(np.log(lo) + u * (np.log(hi) - np.log(lo)))) if log \
            else float(lo + u * (hi - lo))
    return vals


def main():
    rng = np.random.default_rng(0)
    collected = []
    for i in range(N):
        oad.generate_inputs(CONFIG, SOURCE, overwrite=True)
        df = oad.DataFile(WORKDIR_IN)
        nn = {v.name: v for v in df}
        for name, val in sample(rng, i).items():
            if name in nn:
                nn[name].value = [val]
        df.save()
        try:
            oad.optimize_problem(CONFIG, overwrite=True)
        except Exception:
            continue
        d = {v.name: float(np.ravel(v.value)[0]) for v in oad.DataFile(OUT)}
        vdash = d["mission:sizing:dash:speed:multirotor"] * 3.6
        if vdash >= V_TARGET - 1.0:
            cons = {k: v for k, v in d.items() if k.startswith("optimization:constraints")}
            collected.append((vdash, cons))
            print(f"  start {i}: V_dash {vdash:.0f} km/h raccolto ({len(cons)} vincoli)")

    print(f"\nSoluzioni con V_dash >= {V_TARGET:.0f} km/h: {len(collected)}")
    if not collected:
        print("Nessuna a >=350. (Aumenta N o abbassa V_TARGET.)")
        return
    sumv = defaultdict(float); cnt = defaultdict(int); worstc = defaultdict(int)
    for vdash, cons in collected:
        worst = min(cons, key=lambda k: cons[k])
        worstc[worst] += 1
        for k, v in cons.items():
            if v < -1e-3:
                sumv[k] += v; cnt[k] += 1
    rows = [(k, sumv[k] / cnt[k], cnt[k], worstc.get(k, 0)) for k in cnt]
    rows.sort(key=lambda r: r[1])  # piu' violati (piu' negativi) in alto
    print(f"\n{'vincolo':<48}{'viol.media':>11}{'#violato':>9}{'#peggiore':>10}")
    for k, avg, c, w in rows[:14]:
        print(f"  {k.split('constraints:')[-1]:<46}{avg:>11.3f}{c:>9}{w:>10}")


if __name__ == "__main__":
    main()
