# FAST-UAV — Roadmap miglioramenti (P1-SUN / drone F1)

Ultimo aggiornamento: 2026-07-09

Legenda impatto = quanto cambia i risultati. ✅ = fatto.

---

## A. Modelli fisici (realismo)

- [x] **Elica BEMT** — sostituito il polinomiale APC che estrapolava male oltre J~0.6
      (dava potenza~0 / autonomia 2176 min). BEMT hover-capable + guardie (J·sinα<J0,
      Mach punta<0.8). Surrogato rifittato fino a β=1.4. *(era il bug grosso)*
- [x] **Picchiata (dive)** come DATO informativo (non tocca il design). Standalone
      max_speed.py. Design 2kg: livellato 290, picchiata 90°→400 km/h. Spiega la spec
      300-450 km/h reale (= inviluppo di picchiata).
- [ ] **#4 Modello batteria** (sag + stato di carica + C-rate) — impatto medio-alto,
      ~mezza giornata. Il punto chiave NON è il sag in sé (~3.5% per il nostro design)
      ma dimensionare il dash alla tensione di FINE MISSIONE (batteria quasi scarica →
      V più bassa). Livello target = "L1.5": celle Ns×Np, R_pacco=Ns·r_cella/Np,
      V_load in forma chiusa (V_ocv+sqrt(V_ocv²-4RP))/2, SoC per il dash, vincolo C-rate.
      DA FARE INSIEME AL #6 (serve cella racing di riferimento).
- [ ] **#6 Riferimenti racing** (motore + batteria) — IMPATTO ALTO, ~2-4h + dati.
      I motori pesano 33% dell'MTOW e sono sovrastimati (scaling law classe hobby).
      Con riferimenti racing l'MTOW vero scende (forse <2kg). Il fix più importante
      rimasto per la credibilità dei pesi.
- [ ] Drag corpo con **polare CD(α), CL(α)** invece di CD0 costante — medio, mezza giornata.
- [x] **Compressibilità elica** — compressibility_penalty(mach_tip) in physics/propeller.py,
      Cp*=1+k·max(0,M-0.7)². Applicata in sizing+dash. Rivela: capitolato al limite fisico
      (salita 35m/s@6000m -> Mach punta 0.89 -> +72% potenza). Payload 1.19 era ottimista.
- [ ] **Drag eliche in windmilling** in picchiata (ora trascurato) — basso, 1h.
- [ ] **Accelerazione** (100→300 in 2s: correnti/energia di picco) — basso-medio.

## B. Ottimizzazione e workflow

- [x] **#1 Vincolo dash liscio** — Omega_dash come design variable, 6 vincoli lisci
      (thrust/torque/power/rpm/advance/mach). Risolto l'exit-8 cronico. Serve warm-start.
- [ ] **#3a Report post-run automatico** dentro run_design.py (masse, vincoli attivi,
      check V_max) — alto (comodità), ~2h. Ora lo faccio a mano ogni volta.
- [ ] **#3b Sweep Pareto** MTOW-vs-velocità-vs-raggio con grafico — alto, mezza giornata.
      >>> CANDIDATO N.1 PROSSIMO: ora che converge, fa scegliere il target con cognizione.
- [x] **Multi-start automatico** — run_multistart.py: N punti random nei bound (log-scale
      dove serve), ottimizza da ciascuno, tiene il migliore feasible con payload max.
      Salva workdir/best_multistart.xml.
- [ ] File **requirements.yaml** che separa requisiti da tuning (basta sed sui commenti
      XML, fragile) — medio, mezza giornata.
- [ ] **#5 Warning di dominio** sui surrogati (evita la prossima "autonomia 2176 min") —
      medio (sicurezza), ~2h.

## C. Vincoli mancanti (scoperti, non aggiunti)

- [ ] **Ingombro massimo** (Ø elica o span telaio) — il P1-SUN è lanciato da pilone
      An-28 → ha un limite di dimensione che ora NON c'è. Piccolo ma reale.
- [ ] **V_max esatta** invece di "≥ target": invertire il vincolo dash (V_dash variabile,
      massimizza -V_dash, g1 come uguaglianza) → dà la velocità di punta vera.

## D. Validazione

- [ ] Cross-check con **eCalc / xcopterCalc** sul punto hover/crociera — alto (fiducia).
- [ ] Modalità **catalogo COTS** (esiste multirotor_mdo_cots.yaml, MAI PROVATA!) —
      snappa a motori/eliche/batterie reali comprabili. Alto per un drone da $1000.
- [ ] Test di **regressione** (M600→15.4kg, P1-SUN→~2kg) per proteggere i fix.

## E. Progetto lasciato indietro

- [ ] **Drone F1 Red Bull (350 km/h)**: mai finito. Ora con elica BEMT + modulo dash +
      picchiata si rifà pulito. La vecchia soluzione (J=1.43) era irrealizzabile.

## F. Igiene

- [ ] **Git** per i design (ogni esperimento sovrascrive; già perse configurazioni).
- [ ] **.venv fuori da Dropbox** (mai risolto — `attr` non installato; serve
      `sudo apt install attr` poi `attr -s com.dropbox.ignored -V 1 .venv`).

---

## Ordine proposto
1. #3 Report + sweep Pareto (subito utile, basso rischio)
2. #6 + #4 Riferimenti racing + modello batteria (insieme; credibilità pesi)
3. Vincolo ingombro (piccolo, reale per il pilone)
4. Rifare drone F1 (riusa tutto, chiude il primo progetto)

## Stato design P1-SUN attuale (riferimento)
MTOW 2.02 kg | batteria 0.71 kg (~10S) | 4× elica ~5×5.5" (Ø13cm, β=1.11) |
V_max livellato ~290 km/h | picchiata fino ~400 | lancio aereo 5000m, raggio 15km.
Caveat: motori sovrastimati (33% peso), V_max livellato calcolata a tensione piena (no sag).

---
## DA FARE — Interpretazione requisiti (quota di ingaggio vs soffitto)
Aperto 2026-07-18. I requisiti del capitolato ("il sistema deve essere in grado di X")
sono CAPACITA' SEPARATE dell'inviluppo, NON un unico punto simultaneo. Attualmente il
modello verifica il dash 350 km/h a 6000 m (quota max) = caso peggiore -> non chiude.
INTERPRETAZIONE CORRETTA proposta:
  - Vmax 350 km/h  -> verificata a QUOTA DI INGAGGIO realistica (~3000-4000 m), NON al soffitto.
  - Salita 35 m/s  -> a bassa quota (piu' spinta).
  - Quota 6000 m   -> vincolo di SOFFITTO (ci arriva/staziona), non punto del dash.
  - Autonomia/raggio -> missione (puo' includere salita a 6000 + crociera).
SWEEP ha confermato: a 4000m il dash chiude, payload ~1.5kg (binding solo battery
voltage:max -7.5%, che L1_ecm potrebbe risolvere). MTOW cap inefficace.
DA FARE: ristrutturare missione con dash a quota ingaggio + 6000m come soffitto separato;
poi caso a 4000m con L1_ecm per primo design FEASIBLE.
CAVEAT: se il target vola a 6000m, il dash va garantito lassu' (capitolato al limite).
