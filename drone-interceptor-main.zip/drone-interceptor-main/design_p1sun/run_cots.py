#!/usr/bin/env python
"""
Ottimizzazione P1-SUN con componenti OFF-THE-SHELF (catalogo reale) + CMA-ES.

Perche' CMA-ES e non SLSQP: lo snap al catalogo (nearest-neighbor) rende l'obiettivo
NON continuo (a gradini). Un ottimizzatore gradient-based (SLSQP) fallisce -> exit-8.
FAST-UAV raccomanda ufficialmente CMA-ES (evolutivo, gradient-free) per il caso COTS.
Tutto gia' nella libreria: CMAESDriver + pycma. Nessuna reimplementazione.

Uso:
    python run_cots.py                 # ottimizza con catalogo + CMA-ES
"""
import os.path as pth
import fastoad.api as oad
from time import time
from fastuav.utils.drivers.cmaes_driver import CMAESDriver

HERE = pth.dirname(pth.abspath(__file__))
CONFIG = pth.join(HERE, "multirotor_mdo_cots_base.yaml")  # sizing base (dash verificato dopo con max_speed.py)
SOURCE = pth.join(HERE, "problem_inputs.xml")

# 1. Genera gli input dal config COTS
oad.generate_inputs(CONFIG, SOURCE, overwrite=True)

# 2. Costruisci il problema e imposta il driver CMA-ES (non dal YAML: via codice)
conf = oad.FASTOADProblemConfigurator(CONFIG)
prob = conf.get_problem(read_inputs=True, auto_scaling=True)

driver = prob.driver = CMAESDriver()
driver.options["sigma0"] = 0.1
driver.options["penalty_parameter"] = 1.0e8   # scala: obiettivo ~ violazione vincoli
driver.options["penalty_exponent"] = 1.0
driver.CMAOptions["tolfun"] = 1e-6
driver.CMAOptions["tolfunhist"] = 1e-5
driver.CMAOptions["popsize_factor"] = 1

# 3. Setup e run
prob.setup()
print("Ottimizzazione COTS con CMA-ES (puo' richiedere qualche minuto)...")
t0 = time()
prob.optim_failed = prob.run_driver()
dt = round(time() - t0, 1)
prob.write_outputs()
print(f"Fatto in {dt}s | obiettivo = {driver.get_objective_values()}")

# 4. Riepilogo
out = pth.join(HERE, "workdir", "problem_outputs.xml")
df = oad.DataFile(out)
n = {v.name: v for v in df}
def g(k):
    v = n.get(k)
    return float(v.value[0] if hasattr(v.value, "__len__") else v.value) if v else None

W = "data:weight:propulsion:multirotor:"
print("\n" + "=" * 55)
print("  P1-SUN — componenti REALI da catalogo (CMA-ES)")
print("=" * 55)
print(f"  MTOW      : {g('data:weight:mtow'):.2f} kg")
print(f"  Motore    : {g(W+'motor:mass')*1000:.0f} g/cad (Kv {g('data:propulsion:multirotor:motor:speed:constant')*60/6.283:.0f}, Tmax {g('data:propulsion:multirotor:motor:torque:max'):.2f} N·m)")
print(f"  Batteria  : {g(W+'battery:mass')*1000:.0f} g ({g('data:propulsion:multirotor:battery:voltage'):.0f} V)")
print(f"  ESC       : {g(W+'esc:mass')*1000:.0f} g/cad")
print(f"  Elica     : Ø{g('data:propulsion:multirotor:propeller:diameter')*100:.0f} cm, β={g('data:propulsion:multirotor:propeller:beta'):.2f}")
viol = [(v.name.split('constraints:')[1], round(float(v.value[0] if hasattr(v.value,'__len__') else v.value),3))
        for v in df if v.name.startswith('optimization:constraints')
        and float(v.value[0] if hasattr(v.value,'__len__') else v.value) < -1e-3]
print(f"  Vincoli violati: {viol if viol else 'nessuno'}")
print("=" * 55)
