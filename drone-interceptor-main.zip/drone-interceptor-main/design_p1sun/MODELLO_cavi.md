# Modello dei cavi (wires)

Documento di riferimento del modello dei cavi di potenza in FAST-UAV: dimensionamento
della sezione, lunghezza, numero e massa. Il modello e' quello originale del framework
(non modificato in questo progetto).

---

## 1. Scopo e ruolo

I cavi collegano la batteria agli ESC e gli ESC ai motori. Il modello fornisce:

1. il raggio (sezione) del conduttore, dalla corrente che deve portare;
2. la lunghezza e il numero di cavi, dalla geometria e dall'architettura;
3. la massa complessiva del cablaggio.

E' il componente piu' semplice del sistema propulsivo e, in massa, tipicamente
trascurabile (per confronto, il cablaggio di un aereo commerciale pesa lo 0.5-0.8% del
MTOW; su un piccolo multirotore la frazione e' ancora minore).

---

## 2. Raggio del conduttore

Il raggio del cavo e' dimensionato dalla corrente, per legge di scala a partire da un
cavo di riferimento:

```
r = r_ref * (I_wire / I_ref)^(2/3)        [m]
```

dove I_wire e' la corrente che il cavo deve portare. L'esponente 2/3 riflette il
compromesso tra area della sezione (che cresce con la corrente per limitare densita' di
corrente e riscaldamento) e i cavi disponibili reali.

Riferimento: r_ref = 5.2e-3 m, I_ref = 120 A.

Nota: la scala corrente -> sezione e' coerente con la pratica (tabelle AWG): a corrente
maggiore corrisponde un conduttore di sezione maggiore.

---

## 3. Lunghezza e numero di cavi

```
L_cavo = lunghezza_braccio                (multirotore: cavo lungo il braccio)
N_cavi = 3 * N_eliche                       (3 fili per motore: alimentazione trifase)
```

Ogni motore brushless e' trifase e richiede 3 conduttori. La lunghezza del singolo cavo
e' assunta pari alla lunghezza del braccio (batteria al centro, ESC/motore all'estremita').
Per configurazioni ad ala fissa la lunghezza e' riferita alla fusoliera.

---

## 4. Massa

La massa lineare (per unita' di lunghezza) scala con la sezione (raggio al quadrato); la
massa totale e' massa lineare per lunghezza e numero:

```
mu    = mu_ref * (r / r_ref)^2             [kg/m]   massa lineare (~ sezione)
m_cavi = mu * L_cavo * N_cavi              [kg]     massa totale del cablaggio
```

con mu_ref = 0.190 kg/m (calibrato su cavo reale, quindi inclusivo dell'isolante).
La relazione massa ~ sezione * lunghezza e' la fisica esatta del conduttore.

---

## 5. Input / Output

**Input principali:** corrente del cavo (I_wire), lunghezza del braccio
(`data:geometry:arms:length`), numero di eliche, costanti di riferimento
(`models:propulsion:wires:*:reference`).

**Output principali:**
- `data:propulsion:wires:radius`
- `data:propulsion:wires:length`, `:number`
- `data:weight:propulsion:wires:density` (massa lineare)
- `data:weight:propulsion:wires:mass`

---

## 6. Accoppiamento con il resto del modello

La lunghezza del cavo dipende dalla lunghezza del braccio, che a sua volta dipende dal
diametro dell'elica (i bracci sono dimensionati per far entrare le eliche). Quindi
un'elica piu' grande produce cavi piu' lunghi e leggermente piu' pesanti. E' un
accoppiamento di terzo ordine sulla massa totale.

---

## 7. Limiti dichiarati

- **Caduta di tensione non modellata:** il cavo e' considerato ideale (resistenza nulla
  ai fini della tensione); il voltage drop `I * R_cavo` non e' incluso. Per i tratti brevi
  di un multirotore e' piccolo rispetto al sag interno della batteria.
- **Massa del solo conduttore (con riferimento inclusivo):** isolante e guaina non sono
  modellati separatamente; sono inglobati nel valore di riferimento mu_ref.
- **Nessun limite termico esplicito:** il dimensionamento della sezione dalla corrente
  incorpora implicitamente il margine termico tramite il riferimento, ma non c'e' un
  modello di dissipazione conduttore-isolante-aria.
- **Scaling da un unico riferimento:** l'accuratezza decresce allontanandosi dalla classe
  del cavo di riferimento.

---

## 8. Riferimenti

- M. Budinger, S. Delbecq et al., scaling laws e similarity models per il dimensionamento
  preliminare di droni multirotore (base del framework).
- NASA, Power Cable Mass Estimation for Electric Aircraft Propulsion (massa = area *
  densita' del materiale; contributi di conduttore, isolante, guaina).
- Tabelle AWG / capacita' di corrente dei conduttori (pratica UAV/FPV).
