#!/usr/bin/env python
"""
Prototipo BEMT (Blade Element Momentum Theory) per i coefficienti assiali Ct(J), Cp(J)
di un'elica, valido a QUALSIASI advance ratio.

Obiettivo: sostituire i polinomiali di FAST-UAV (aero_coefficients_axial), che estrapolano
male oltre J~0.6, con un modello fisico che non si rompe agli alti J tipici del volo veloce.

Questo script NON tocca il pacchetto: valida solo il BEMT contro i polinomiali esistenti nel
range dove questi ultimi sono affidabili (J <= 0.6), poi mostra il comportamento oltre.

Uso:
    python bemt_prototype.py            # confronto e salva bemt_validation.png
"""
import numpy as np

# ---------------------------------------------------------------------------
# 1) Polinomiali attuali di FAST-UAV (copia esatta da surrogate_models.py)
# ---------------------------------------------------------------------------
CT_POLY = np.array([0.02791, 0.11867, 0.27334, -0.28852, -0.06543,
                    -0.23504, 0.02104, 0.0, 0.0, 0.18677])
CP_POLY = np.array([0.01813, -0.06218, 0.35712, -0.23774, 0.00343,
                    -0.1235, 0.0, 0.07549, 0.0, 0.0])


def poly_axial(beta, J):
    """Ct, Cp assiali secondo i polinomiali FAST-UAV (con lo stesso clamp a 1e-10)."""
    ct = (CT_POLY[0] + CT_POLY[1]*beta + CT_POLY[2]*beta**2 + CT_POLY[3]*beta**3
          + CT_POLY[4]*J + CT_POLY[5]*J**2 + CT_POLY[6]*J**3
          + CT_POLY[7]*beta*J + CT_POLY[8]*beta**2*J + CT_POLY[9]*beta*J**2)
    cp = (CP_POLY[0] + CP_POLY[1]*beta + CP_POLY[2]*beta**2 + CP_POLY[3]*beta**3
          + CP_POLY[4]*J + CP_POLY[5]*J**2 + CP_POLY[6]*J**3
          + CP_POLY[7]*beta*J + CP_POLY[8]*beta**2*J + CP_POLY[9]*beta*J**2)
    return max(1e-10, ct), max(1e-10, cp)


# ---------------------------------------------------------------------------
# 2) Modello BEMT
# ---------------------------------------------------------------------------
def bemt_axial(beta, J, n_blades=2, chord_to_radius=0.15, n_elem=40,
               a0=2*np.pi, alpha0_deg=0.0, cd0=0.02, k_cd=0.05,
               cl_max=1.2, root_cut=0.15):
    """
    Ct, Cp assiali via BEMT. Convenzione coefficienti come FAST-UAV:
        Ct = T / (rho * n^2 * D^4),  Cp = P / (rho * n^3 * D^5)   (n in giri/s)

    beta            : pitch-to-diameter ratio p/D (svergolamento a pitch costante)
    J               : advance ratio V/(nD)
    n_blades        : numero di pale
    chord_to_radius : corda/raggio (costante, sezione rappresentativa)
    a0              : pendenza Cl-alpha (1/rad), ~2*pi
    cd0, k_cd       : polare di resistenza Cd = cd0 + k_cd*Cl^2
    cl_max          : stallo (cap sul Cl)
    root_cut        : frazione di raggio non portante alla radice
    """
    R = 0.5                      # raggio adimensionale (D=1) -> Ct/Cp indipendenti da D
    D = 2 * R
    x = np.linspace(root_cut, 1.0, n_elem)   # r/R
    dx = x[1] - x[0]
    r = x * R
    chord = chord_to_radius * R              # corda costante
    sigma = n_blades * chord / (2 * np.pi * r)  # solidita' locale

    # velocita' assiale e rotazione: con D=1, n=1 giro/s => V = J (poiche' J=V/(nD)=V)
    n_rps = 1.0
    Omega = 2 * np.pi * n_rps
    V = J * n_rps * D            # = J

    # angolo di calettamento locale: theta(x) = atan(pitch/(2*pi*r)) = atan(beta/(pi*x))
    theta = np.arctan(beta / (np.pi * x))
    alpha0 = np.deg2rad(alpha0_deg)

    dT = np.zeros(n_elem)
    dQ = np.zeros(n_elem)
    for i in range(n_elem):
        # iterazione sui fattori di induzione (assiale a, rotazionale a')
        a, ap = 0.1, 0.01
        for _ in range(100):
            Ua = V * (1 + a)               # velocita' assiale locale
            Ut = Omega * r[i] * (1 - ap)   # velocita' tangenziale locale
            phi = np.arctan2(Ua, Ut)       # angolo di afflusso
            W2 = Ua**2 + Ut**2
            alpha = theta[i] - phi         # angolo d'attacco locale
            Cl = np.clip(a0 * (alpha - alpha0), -cl_max, cl_max)
            Cd = cd0 + k_cd * Cl**2
            cphi, sphi = np.cos(phi), np.sin(phi)
            Cn = Cl * cphi - Cd * sphi     # coeff. normale (spinta)
            Ctan = Cl * sphi + Cd * cphi   # coeff. tangenziale (coppia)
            # Prandtl tip loss
            f = n_blades / 2 * (1 - x[i]) / max(x[i] * sphi, 1e-6)
            F = max(2 / np.pi * np.arccos(np.exp(-min(f, 20))), 1e-3)
            # nuovi fattori di induzione da bilancio quantita' di moto
            denom_a = 4 * F * sphi**2 / (sigma[i] * Cn + 1e-9) - 1
            denom_ap = 4 * F * sphi * cphi / (sigma[i] * Ctan + 1e-9) + 1
            a_new = 1 / denom_a if denom_a > 1e-6 else a
            ap_new = 1 / denom_ap if denom_ap > 1e-6 else ap
            a_new = np.clip(a_new, -0.5, 2.0)
            ap_new = np.clip(ap_new, -0.5, 2.0)
            if abs(a_new - a) < 1e-6 and abs(ap_new - ap) < 1e-6:
                a, ap = a_new, ap_new
                break
            a = 0.5 * a + 0.5 * a_new       # rilassamento
            ap = 0.5 * ap + 0.5 * ap_new
        # forze per unita' di raggio (per pala) -> integrazione
        q = 0.5 * W2                        # rho=1
        dT[i] = n_blades * q * chord * Cn
        dQ[i] = n_blades * q * chord * Ctan * r[i]

    T = np.trapezoid(dT, r)
    Q = np.trapezoid(dQ, r)
    P = Omega * Q
    # coefficienti in convenzione "n in giri/s": Ct=T/(rho n^2 D^4), Cp=P/(rho n^3 D^5)
    Ct = T / (n_rps**2 * D**4)
    Cp = P / (n_rps**3 * D**5)
    return max(1e-10, Ct), max(1e-10, Cp)


# ---------------------------------------------------------------------------
# 3) Confronto
# ---------------------------------------------------------------------------
def main():
    betas = [0.5, 0.7, 0.9]
    J = np.linspace(0.0, 1.6, 33)
    print(f"{'beta':>5} {'J':>6} | {'Ct_poly':>9} {'Ct_bemt':>9} | {'Cp_poly':>9} {'Cp_bemt':>9}")
    rows = {}
    for beta in betas:
        ct_p, cp_p, ct_b, cp_b = [], [], [], []
        for j in J:
            a, b = poly_axial(beta, j)
            c, d = bemt_axial(beta, j)
            ct_p.append(a); cp_p.append(b); ct_b.append(c); cp_b.append(d)
        rows[beta] = (ct_p, cp_p, ct_b, cp_b)
        for j, a, b, c, d in list(zip(J, ct_p, cp_p, ct_b, cp_b))[::4]:
            print(f"{beta:>5.2f} {j:>6.2f} | {a:>9.4f} {c:>9.4f} | {b:>9.4f} {d:>9.4f}")
        print("-"*60)

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(1, 2, figsize=(13, 5))
        colors = {0.5: "tab:blue", 0.7: "tab:orange", 0.9: "tab:green"}
        for beta in betas:
            ct_p, cp_p, ct_b, cp_b = rows[beta]
            axes[0].plot(J, ct_p, "--", color=colors[beta], label=f"poly β={beta}")
            axes[0].plot(J, ct_b, "-", color=colors[beta], label=f"BEMT β={beta}")
            axes[1].plot(J, cp_p, "--", color=colors[beta])
            axes[1].plot(J, cp_b, "-", color=colors[beta])
        for ax, t in zip(axes, ["Ct(J)", "Cp(J)"]):
            ax.axvspan(0.6, 1.6, alpha=0.08, color="red")
            ax.axvline(0.6, ls=":", color="red")
            ax.set_xlabel("J"); ax.set_title(t); ax.grid(alpha=0.3)
        axes[0].legend(fontsize=8)
        axes[0].text(0.62, axes[0].get_ylim()[1]*0.9, "estrapolazione poly", color="red", fontsize=8)
        fig.suptitle("BEMT vs polinomiali FAST-UAV — zona rossa = fuori dominio del fit")
        fig.tight_layout()
        fig.savefig("bemt_validation.png", dpi=110)
        print("Grafico salvato: bemt_validation.png")
    except Exception as e:
        print(f"(plot saltato: {e})")


if __name__ == "__main__":
    main()
