#!/usr/bin/env python
"""
Solver di VELOCITA' MASSIMA per un multirotore dimensionato da FAST-UAV.

Usa le STESSE classi del pacchetto (garanzia di coerenza col dimensionamento):
  - MultirotorFlightModel      -> resistenza/assetto in volo livellato
  - PropellerAerodynamicsModel -> spinta/potenza elica (coeff. BEMT letti dall'XML)

Idea: in volo livellato (RoC=0) a velocita' V serve una spinta T_req(V) per vincere
la resistenza. Il propulsore puo' erogare una spinta massima T_avail(V) limitata da:
  - coppia max motore, potenza max motore, giri max (Kv * V_batt)
  - fisica dell'elica: a J = V/(nD) oltre J0~beta la spinta si annulla
La velocita' massima e' la V piu' alta dove  T_avail(V) >= T_req(V)  per elica.

Uso:
    python max_speed.py                       # usa workdir/problem_outputs.xml
    python max_speed.py --xml altro.xml
    python max_speed.py --target 250          # stampa se raggiunge 250 km/h
"""
import argparse
import numpy as np
import fastoad.api as oad
from scipy.constants import g
from stdatm import Atmosphere

from fastuav.models.scenarios.thrust.flight_models import MultirotorFlightModel as FM
from fastuav.models.propulsion.propeller.aerodynamics.surrogate_models import (
    PropellerAerodynamicsModel as PAM,
)

PID = "multirotor"


def load(xml):
    df = oad.DataFile(xml)
    n = {v.name: v for v in df}
    def get(k, d=None):
        v = n.get(k)
        if v is None:
            return d
        val = v.value
        return np.array(val) if hasattr(val, "__len__") and len(val) > 1 else float(val[0] if hasattr(val, "__len__") else val)
    return get


def max_thrust_per_prop(V, alpha, D, beta, ct_dyn, cp_dyn, rho,
                        Omega_max, Q_max, P_max, n_pts=400, a_sound=340.0, mach_tip_max=0.80):
    """Massima spinta di UNA elica a velocita' V, cercando i giri ottimali entro i limiti motore."""
    best_T = 0.0
    best = None
    J0 = ct_dyn[-2] + ct_dyn[-1] * beta                     # advance ratio di spinta nulla (assiale)
    sin_a = np.sin(alpha)
    for Omega in np.linspace(1.0, Omega_max, n_pts):        # rad/s
        n_rps = Omega / (2 * np.pi)
        V_tip = Omega * D / 2.0
        if V_tip > mach_tip_max * a_sound:                  # limite di compressibilita' alla punta
            continue
        J = V / (n_rps * D) if n_rps > 0 else 1e9
        # GUARDIA FISICA (volo veloce, disco inclinato): conta la componente ASSIALE
        # dell'advance ratio; oltre J0 l'elica va in windmilling.
        if J * sin_a >= J0:
            continue
        ct, cp = PAM.aero_coefficients_incidence(beta, J, alpha,
                                                 ct_model=ct_dyn, cp_model=cp_dyn)
        CT_MAX, CP_MAX = 0.20, 0.15                          # tetti fisici per eliche reali
        if ct > CT_MAX or cp > CP_MAX or ct <= 1e-6:
            continue
        T = ct * rho * n_rps**2 * D**4                       # [N] spinta elica
        P = cp * rho * n_rps**3 * D**5                       # [W] potenza aerodinamica
        Q = P / Omega if Omega > 0 else 0.0                  # [N*m] coppia
        if Q > Q_max or P > P_max:                           # limiti motore
            continue
        if T > best_T:
            best_T, best = T, (Omega, J, ct, P, Q)
    return best_T, best


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xml", default="workdir/problem_outputs.xml")
    ap.add_argument("--target", type=float, default=None, help="velocita' obiettivo [km/h]")
    ap.add_argument("--altitude", type=float, default=None, help="quota di valutazione [m] (default: quota crociera)")
    args = ap.parse_args()

    get = load(args.xml)
    D = get(f"data:propulsion:{PID}:propeller:diameter")
    beta = get(f"data:propulsion:{PID}:propeller:beta")
    N = int(get(f"data:propulsion:{PID}:propeller:number"))
    m = get("data:weight:mtow")
    CD0 = get(f"data:aerodynamics:{PID}:CD0")
    CL0 = 0.0  # come in cruise.py: il corpo produce solo resistenza, niente portanza
    S_front = get("data:geometry:projected_area:front")
    S_top = get("data:geometry:projected_area:top")
    Vbatt = get(f"data:propulsion:{PID}:battery:voltage")
    Kv = get(f"data:propulsion:{PID}:motor:speed:constant")      # rad/V/s
    Q_max = get(f"data:propulsion:{PID}:motor:torque:max")
    P_max = get(f"data:propulsion:{PID}:motor:power:takeoff")    # potenza di picco disponibile
    ct_dyn = get(f"data:propulsion:{PID}:propeller:Ct:dynamic:polynomial")
    cp_dyn = get(f"data:propulsion:{PID}:propeller:Cp:dynamic:polynomial")
    alt = args.altitude if args.altitude is not None else get("mission:sizing:main_route:cruise:altitude")
    _atm = Atmosphere(alt, altitude_in_feet=False)
    rho = _atm.density
    a_sound = _atm.speed_of_sound

    Omega_max = Kv * Vbatt                                       # giri max a piena tensione
    J0_beta = ct_dyn[-2] + ct_dyn[-1] * beta                     # advance ratio di spinta nulla

    print("="*60)
    print(f"  Design: MTOW {m:.2f} kg | {N} eliche Ø{D*100:.1f} cm β={beta:.2f}")
    print(f"  Motore: Q_max {Q_max:.2f} N·m | P_max {P_max:.0f} W | Ω_max {Omega_max:.0f} rad/s ({Omega_max*60/2/np.pi:.0f} rpm)")
    print(f"  Quota {alt:.0f} m (ρ={rho:.3f}) | J0≈β = {J0_beta:.2f}")
    print("="*60)
    print(f"  {'V [km/h]':>9} {'T_req/el':>9} {'T_disp/el':>10} {'J':>6} {'margine':>9}")

    Vs = np.arange(20, 501, 10) / 3.6                            # m/s
    V_max = 0.0
    for V in Vs:
        alpha = float(np.ravel(FM.get_angle_of_attack(m, V, 0.0, S_front, S_top, CD0, CL0, rho))[0])  # RoC=0
        T_req_tot = FM.get_thrust(m, V, 0.0, alpha, S_front, S_top, CD0, CL0, rho)
        T_req = T_req_tot / N
        T_av, det = max_thrust_per_prop(V, alpha, D, beta, ct_dyn, cp_dyn, rho,
                                        Omega_max, Q_max, P_max, a_sound=a_sound)
        J = det[1] if det else float("nan")
        ok = T_av >= T_req
        if ok:
            V_max = V
        mark = "  OK" if ok else "  <-- NON basta"
        if V*3.6 % 30 < 10 or (not ok and V_max > 0):           # stampa 1 su 3 + la soglia di taglio
            print(f"  {V*3.6:>9.0f} {T_req:>9.1f} {T_av:>10.1f} {J:>6.2f} {mark}")

    print("="*60)
    print(f"  VELOCITA' MASSIMA in VOLO LIVELLATO: {V_max*3.6:.0f} km/h  ({V_max:.1f} m/s)")
    if args.target:
        tgt = args.target/3.6
        print(f"  Obiettivo {args.target:.0f} km/h (livellato): {'RAGGIUNTO' if V_max>=tgt else 'NON raggiunto'}")
    print("="*60)

    # --- PICCHIATA (dive): la gravita' aggiunge W*sin(gamma) come spinta extra;
    # a naso in giu' conta l'area FRONTALE (carenata, meno drag). ---
    g = 9.81
    W = m * g
    print("  VELOCITA' MASSIMA in PICCHIATA (gravita' assist):")
    print(f"  {'angolo':>8} {'V_max [km/h]':>13}")
    for gamma_deg in (30, 45, 60, 90):
        gamma = np.radians(gamma_deg)
        # in picchiata il disco e' quasi assiale al flusso: alpha ~ pi/2 (spinta lungo la traiettoria)
        alpha_dive = np.pi / 2
        Vmax_dive = 0.0
        for V in np.arange(20, 701, 10) / 3.6:
            # drag a naso in giu': area frontale
            D_drag = 0.5 * rho * CD0 * S_front * V**2
            T_av, _ = max_thrust_per_prop(V, alpha_dive, D, beta, ct_dyn, cp_dyn, rho,
                                          Omega_max, Q_max, P_max, a_sound=a_sound)
            if (N * T_av + W * np.sin(gamma)) >= D_drag:
                Vmax_dive = V
        print(f"  {gamma_deg:>7}° {Vmax_dive*3.6:>12.0f}")
    print("="*60)


if __name__ == "__main__":
    main()
