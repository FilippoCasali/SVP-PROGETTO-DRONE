#!/usr/bin/env python
"""
Sweep sulla quota (ceiling): per ogni quota, Modo A (max V_dash) con N start casuali,
tiene il migliore e riporta V_dash, beta, MTOW, violazione. Mostra come variano la
velocita' di intercettazione garantita e il passo elica al variare della quota.

Uso: python sweep_altitude.py [N_start]   (default 6)
"""
import sys, subprocess
import os.path as pth
import numpy as np
import fastoad.api as oad

HERE = pth.dirname(pth.abspath(__file__))
PY = sys.executable
CONFIG = pth.join(HERE, "multirotor_mdo.yaml")
SOURCE = pth.join(HERE, "problem_inputs.xml")
WORKDIR_IN = pth.join(HERE, "workdir", "problem_inputs.xml")
OUT = pth.join(HERE, "workdir", "problem_outputs.xml")

N = int(sys.argv[1]) if len(sys.argv) > 1 else 6
CEILINGS = [500, 1500, 3000, 4500, 6000]

DVS = [
    ("optimization:variables:propulsion:multirotor:propeller:beta", 0.6, 1.4, False),
    ("optimization:variables:propulsion:multirotor:propeller:ND:k", 0.3, 1.0, False),
    ("optimization:variables:propulsion:multirotor:dash:throttle", 0.4, 1.0, False),
    ("optimization:variables:propulsion:multirotor:motor:torque:k", 1.5, 12.0, True),
    ("optimization:variables:propulsion:multirotor:motor:speed:k", 0.5, 5.0, True),
    ("optimization:variables:propulsion:multirotor:battery:voltage:k", 2.0, 9.0, True),
    ("optimization:variables:propulsion:multirotor:esc:power:k", 1.5, 12.0, True),
    ("optimization:variables:geometry:body:diameter", 0.08, 0.25, False),
    ("mission:sizing:dash:speed:multirotor", 41.7, 111.1, False),
    ("mission:sizing:main_route:cruise:speed:multirotor", 41.7, 111.1, False),
]


def sample(rng, i):
    vals = {}
    for name, lo, hi, log in DVS:
        if "dash:speed" in name:
            u = 0.4 + 0.6 * rng.random()   # start medio-alto
        elif i == 0:
            u = 0.5
        elif "propeller:beta" in name:
            u = 0.3 + 0.7 * rng.random()
        else:
            u = rng.random()
        vals[name] = float(np.exp(np.log(lo) + u * (np.log(hi) - np.log(lo)))) if log \
            else float(lo + u * (hi - lo))
    return vals


def main():
    rng = np.random.default_rng(0)
    print(f"{'quota':>6}{'Vdash kmh':>11}{'beta':>7}{'MTOW':>7}{'viol':>9}{'esito':>10}")
    rows = []
    for ceil in CEILINGS:
        subprocess.run([PY, pth.join(HERE, "set_requirements.py"), "1.0", str(ceil)],
                       cwd=HERE, capture_output=True)
        best = None
        for i in range(N):
            oad.generate_inputs(CONFIG, SOURCE, overwrite=True)
            df = oad.DataFile(WORKDIR_IN)
            nn = {v.name: v for v in df}
            for name, val in sample(rng, i).items():
                if name in nn:
                    nn[name].value = [val]
            df.save()
            try:
                oad.optimize_problem(CONFIG, overwrite=True)
            except Exception:
                continue
            d = {v.name: float(np.ravel(v.value)[0]) for v in oad.DataFile(OUT)}
            worst = min([v for k, v in d.items() if k.startswith("optimization:constraints")] + [0.0])
            vdash = d["mission:sizing:dash:speed:multirotor"] * 3.6
            beta = d["data:propulsion:multirotor:propeller:beta"]
            mtow = d["data:weight:mtow"]
            feas = worst >= -1e-3
            score = (feas, vdash if feas else worst)
            if best is None or score > best[0]:
                best = (score, vdash, beta, mtow, worst)
        if best:
            _, vdash, beta, mtow, worst = best
            tag = "FEASIBLE" if worst >= -1e-3 else "infeas"
            print(f"{ceil:>6}{vdash:>11.1f}{beta:>7.2f}{mtow:>7.2f}{worst:>9.2f}{tag:>10}")
            rows.append((ceil, vdash, beta, mtow, worst))
    print("\n(Modo A: V_dash massimizzata; 'viol' = vincolo peggiore, <0 = infeasible)")


if __name__ == "__main__":
    main()
