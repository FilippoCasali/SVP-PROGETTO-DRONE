# Report tecnico — Modello aerodinamico e di dimensionamento dell'elica

**Contesto:** dimensionamento preliminare (MDO) di un drone multirotore ad alta velocità
in ambiente FAST-UAV / FAST-OAD / OpenMDAO.
**Oggetto:** descrizione del modello dell'elica utilizzato per il calcolo delle prestazioni
propulsive e per il dimensionamento geometrico/massico, con ipotesi, dominio di validità
e modifiche apportate rispetto alla versione originale del framework.

---

## 1. Scopo e ruolo del modello

Il modello dell'elica fornisce, in ogni fase di volo (hover, decollo, salita, crociera,
scatto ad alta velocità "dash"):

1. i coefficienti aerodinamici adimensionali di spinta e potenza;
2. la spinta, la potenza e la coppia effettive a partire dalla condizione di volo;
3. il diametro e la massa dell'elica in fase di dimensionamento.

La coppia calcolata costituisce l'ingresso per il modello del motore; la spinta chiude
l'equilibrio di volo; la potenza alimenta il bilancio energetico e il dimensionamento
della batteria.

---

## 2. Grandezze di riferimento

I coefficienti sono definiti secondo la convenzione standard (n = velocità di rotazione
in giri/s, D = diametro, rho = densità dell'aria):

```
Ct = T / (rho * n^2 * D^4)          [-]   coefficiente di spinta
Cp = P / (rho * n^3 * D^5)          [-]   coefficiente di potenza
J  = V / (n * D)                    [-]   advance ratio (rapporto di avanzamento)
```

Variabili indipendenti del modello:
- **beta** = passo/diametro (pitch-to-diameter ratio) — parametro geometrico dell'elica;
- **J** = advance ratio — condizione operativa;
- **alpha** = angolo del disco rotore rispetto al flusso (pi/2 = flusso assiale in hover;
  valori piccoli = flusso quasi radente in volo veloce orizzontale).

---

## 3. Calcolo dei coefficienti aerodinamici

Il modello prevede tre regimi, a fedeltà crescente.

### 3.1 Regime statico (J = 0)
Usato per hover e decollo. Relazione lineare in beta:

```
Ct_static = a0 + a1 * beta
Cp_static = b0 + b1 * beta
```

I coefficienti (a0, a1, b0, b1) sono ricavati per fit; nel caso corrente sono stati
ri-derivati dal modello BEMT (vedi §7).

### 3.2 Regime assiale (J > 0, flusso allineato all'asse)
Superficie di risposta polinomiale (cubica in beta e J, con termini incrociati):

```
Ct_axial = m0 + m1*beta + m2*beta^2 + m3*beta^3
              + m4*J + m5*J^2 + m6*J^3
              + m7*beta*J + m8*beta^2*J + m9*beta*J^2
```

(10 coefficienti; forma identica per Cp con parametri propri.)

### 3.3 Regime a incidenza generica (volo veloce a disco inclinato)
È la funzione impiegata in crociera e dash. Applica al risultato assiale una correzione
per flusso non allineato, secondo il modello analitico di **Y. Leng et al. (2019)**,
"An Analytical Model For Propeller Aerodynamic Efforts At High Incidence".

Passi:

```
1) Componente assiale dell'advance ratio:
   J_axial = J * sin(alpha)
   Ct_axial, Cp_axial = polinomiale(beta, J_axial)          [regime 3.2]

2) Advance ratio di spinta/potenza nulla (windmilling), lineare in beta:
   J0_t = c_(n-1) + c_n * beta        (~ beta)
   J0_p = d_(n-1) + d_n * beta

3) Fattore di solidità e correzione di incidenza:
   sigma = n_blades * (c/R) / pi
   pitch_angle = arctan(beta / (0.7*pi))
   delta = (3/2)*cos(pitch_angle)*[ 1 + (sigma/tan(pitch_angle)) *
           (1 + sqrt(1 + 2*tan(pitch_angle)/sigma)) * (1 - sin(alpha)) ]

   eta_t = 1 + (J*cos(alpha)/(pi*r_norm))^2 / [2*(1 - J/J0_t*sin(alpha))] * delta
   eta_p = 1 + (J*cos(alpha)/(pi*r_norm))^2 / [2*(1 - J/J0_p*sin(alpha))] * delta

4) Coefficienti finali:
   Ct = Ct_axial * eta_t
   Cp = Cp_axial * eta_p
```

Parametri geometrici assunti costanti: numero di pale n_blades = 2, corda/raggio
c/R = 0.15, sezione rappresentativa a r_norm = 0.75.

Significato fisico: **J0 ~ beta** è l'advance ratio oltre il quale l'elica non produce
più spinta (windmilling). È una soglia fisica fondamentale per il volo veloce.

---

## 4. Correzioni aggiuntive introdotte

### 4.1 Compressibilità alle punte
La superficie di risposta non include effetti di comprimibilità. Alle alte velocità di
rotazione le punte delle pale raggiungono numeri di Mach transonici, con brusco aumento
della potenza assorbita (onde d'urto sulle sezioni). È stata introdotta una penalità sul
coefficiente di potenza in funzione del Mach di punta:

```
M_tip = omega * (D/2) / a_suono
Cp_corretto = Cp * ( 1 + k * max(0, M_tip - M_dd)^n )
```

Parametri: M_dd = 0.70 (Mach di drag-divergence), k = 20, n = 2, calibrati su dati di
letteratura (NASA TR: circa +20% di potenza a M_tip = 0.80, crescita rapida oltre).
Effetto: a M_tip = 0.80 penalità +20%; a 0.89 penalità +72%.

### 4.2 Guardie di dominio (nel modulo di verifica velocità massima)
Nel calcolo della capacità di velocità massima sono imposte:
- condizione di non-windmilling: J*sin(alpha) < 0.95 * J0;
- limite di comprimibilità: M_tip < 0.80.

Servono a evitare che il modello di incidenza venga interrogato fuori dal suo dominio di
validità (a forte disallineamento e alto J produce valori non fisici).

---

## 5. Conversione in grandezze dimensionali

Data la spinta richiesta T per elica, si invertono le definizioni:

```
n = sqrt( T / (Ct * rho * D^4) )      [giri/s]   velocità di rotazione necessaria
P = Cp * rho * n^3 * D^5              [W]        potenza assorbita
Q = P / omega                         [N*m]      coppia (input al modello motore)
eta = T * V / P                       [-]        rendimento propulsivo
```

---

## 6. Dimensionamento geometrico e massico

Il **diametro** non è una variabile libera: è determinato dalla spinta di picco (fase di
decollo, spinta = T/W * peso) e dalla velocità di punta massima ammessa ND_max:

```
D = sqrt( T_takeoff / (Ct_static * rho * ND_max^2) )
```

La **massa** segue una legge di similitudine geometrica (scala col cubo del diametro),
a partire da un'elica di riferimento:

```
m_elica = m_ref * (D / D_ref)^3
```

con m_ref = 0.015 kg, D_ref = 0.2794 m (elica APC 11", riferimento DJI M600).
Limite rigido di velocità di punta: ND_max = 220 m/s.

---

## 7. Modifiche rispetto alla versione originale del framework

La versione originale di FAST-UAV utilizza superfici di risposta polinomiali fittate su
dati sperimentali di eliche APC "Multi-Rotor", valide per beta <= 0.6 e advance ratio
J <~ 0.6. Per l'applicazione ad alta velocità (advance ratio e passi elevati) sono state
apportate le seguenti modifiche:

1. **Ri-derivazione dei coefficienti da modello BEMT.** È stato implementato un modello
   Blade Element Momentum Theory (formulazione a velocità indotta assoluta, valida anche
   a punto fisso; tip-loss di Prandtl; polare di sezione regolarizzata), calibrato sui
   dati statici APC. Su di esso è stata rifittata la superficie di risposta (stessa forma
   funzionale) su dominio esteso: beta in [0.3, 1.4], J in [0, 2.0]. RMS del fit ~0.002 su
   Ct e Cp.
   Motivazione: i polinomiali originali, estrapolati oltre il dominio, producevano
   coefficienti non fisici (potenza che collassa a zero, advance ratio di spinta nulla
   sovrastimato del ~20%).

2. **Aggiunta della correzione di comprimibilità** (§4.1), assente nel modello originale.
   Motivazione: nell'inviluppo di volo considerato le punte operano a Mach 0.6-0.9, regime
   in cui le perdite non sono trascurabili.

3. **Guardie di dominio** (§4.2) nel modulo di verifica della velocità massima.

Il modello di conversione (§5) e di dimensionamento (§6) è invariato rispetto all'originale.

---

## 8. Ipotesi e limiti di validità

**Ipotesi principali:**
- geometria di pala non parametrizzata in dettaglio (numero pale, corda/raggio, sezione
  rappresentativa fissati);
- polare di sezione e comportamento post-stallo modellati in forma semplificata (BEMT);
- correzione di incidenza secondo Leng, valida per disco moderatamente inclinato.

**Limiti noti:**
- il fit dei coefficienti è valido per beta <= 1.4; oltre, estrapolazione;
- assenza di effetti del numero di Reynolds sull'elica (rilevanti a bassa scala/quota);
- la penalità di comprimibilità è calibrata su dati di letteratura, non su dati
  sperimentali specifici dell'elica in esame; fornisce l'ordine di grandezza corretto ma
  non un valore certificato;
- il modello di incidenza degrada a disallineamento estremo (alpha -> 0 con J alto):
  gestito con guardie di dominio, non con modellazione fisica completa;
- per la velocità di punta in regime transonico spinto (Mach > ~0.85) il modello va inteso
  come estrapolazione conservativa, da validare con metodi di fedeltà superiore
  (CFD, dati di galleria) prima di conclusioni progettuali definitive.

**Raccomandazione di validazione:** confronto dei coefficienti Ct/Cp e del rendimento con
dati sperimentali (database UIUC / APC ad alto advance ratio) o con analisi CFD nel punto
operativo di crociera e dash, e verifica indipendente della velocità massima raggiungibile.

---

## 9. Riferimenti

- Y. Leng et al., "An Analytical Model For Propeller Aerodynamic Efforts At High
  Incidence", 2019.
- M. Budinger, S. Delbecq et al., scaling laws e similarity models per il dimensionamento
  preliminare di droni multirotore (base del framework FAST-UAV).
- NASA Technical Reports, effetti di comprimibilità su eliche full-scale in decollo e
  salita.
- UIUC Propeller Data Site (dati sperimentali di riferimento per la validazione).
