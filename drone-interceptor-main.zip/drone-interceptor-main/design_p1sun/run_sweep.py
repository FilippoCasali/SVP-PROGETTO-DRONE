#!/usr/bin/env python
"""
Sweep di sensibilita' sui requisiti: varia UNA leva alla volta (altre a capitolato)
e misura quanto il design si avvicina alla feasibilita' e il payload risultante.

Serve a capire QUALE requisito rilassare costa meno per rendere il capitolato
realizzabile. Ogni punto = una ottimizzazione con warm-start.

Uso:  python run_sweep.py
"""
import subprocess, sys, re
import os.path as pth
import numpy as np
import fastoad.api as oad

HERE = pth.dirname(pth.abspath(__file__))
CFG = pth.join(HERE, "multirotor_mdo.yaml")
SRC = pth.join(HERE, "problem_inputs.xml")
OUT = pth.join(HERE, "workdir", "problem_outputs.xml")

# leve da esplorare: (nome, [variabili input da settare], [valori])
SWEEPS = {
    "quota [m]": (
        ["mission:sizing:main_route:cruise:altitude",
         "mission:sizing:dash_route:cruise:altitude",
         "mission:sizing:main_route:takeoff:altitude"],
        [6000, 5000, 4000, 3000],
    ),
    "MTOW cap [kg]": (
        ["data:weight:mtow:requirement"],
        [6.0, 7.0, 8.0, 9.0],
    ),
}

WARM = {
    "optimization:variables:propulsion:multirotor:propeller:beta": 1.0,
    "optimization:variables:propulsion:multirotor:dash:throttle": 0.75,
    "optimization:variables:propulsion:multirotor:battery:voltage:k": 5.0,
    "optimization:variables:propulsion:multirotor:motor:speed:k": 2.0,
    "optimization:variables:propulsion:multirotor:motor:torque:k": 4.0,
    "optimization:variables:weight:mtow:k": 6.0,
    "optimization:variables:geometry:body:diameter": 0.13,
    "mission:sizing:payload:mass": 0.6,
}


def worst_viol_and_payload():
    df = oad.DataFile(OUT); n = {v.name: v for v in df}
    worst = 0.0
    for v in df:
        if v.name.startswith("optimization:constraints"):
            val = float(np.ravel(v.value)[0])
            # vincoli con upper (airspeed) hanno banda: considera solo lower<0
            worst = min(worst, val)
    pay = float(np.ravel(n["mission:sizing:payload:mass"].value)[0])
    mtow = float(np.ravel(n["data:weight:mtow"].value)[0])
    return worst, pay, mtow


def run_point(overrides):
    subprocess.run([sys.executable, pth.join(HERE, "set_requirements.py"), "1.0"],
                   capture_output=True)
    oad.generate_inputs(CFG, SRC, overwrite=True)
    df = oad.DataFile(pth.join(HERE, "workdir", "problem_inputs.xml"))
    nn = {v.name: v for v in df}
    for k, val in {**WARM, **overrides}.items():
        if k in nn:
            nn[k].value = [val]
    df.save()
    try:
        oad.optimize_problem(CFG, overwrite=True)
        return worst_viol_and_payload()
    except Exception as e:
        return (None, None, str(e)[:30])


def main():
    # assicura L0 (piu' veloce per lo sweep esplorativo)
    s = open(CFG).read()
    s = re.sub(r"battery_fidelity: \w+", "battery_fidelity: L0_scaling", s)
    open(CFG, "w").write(s)

    print("SWEEP DI SENSIBILITA' (L0, T/W da set_requirements)\n")
    for leva, (vars_, valori) in SWEEPS.items():
        print(f"### {leva}")
        print(f"  {'valore':>10} {'max viol':>10} {'payload':>9} {'MTOW':>7}  {'feasible':>9}")
        for val in valori:
            ov = {v: val for v in vars_}
            worst, pay, mtow = run_point(ov)
            if worst is None:
                print(f"  {val:>10} errore: {mtow}")
                continue
            feas = "SI" if worst >= -1e-3 else "no"
            print(f"  {val:>10} {worst:>10.3f} {pay:>9.2f} {mtow:>7.2f}  {feas:>9}")
        print()


if __name__ == "__main__":
    main()
