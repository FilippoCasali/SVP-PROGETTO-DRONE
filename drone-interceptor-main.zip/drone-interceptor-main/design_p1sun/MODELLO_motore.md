# Modello del motore elettrico (BLDC)

Documento di riferimento del modello del motore brushless in FAST-UAV: fisica elettrica,
leggi di scala per il dimensionamento, input/output e limiti. Il modello e' quello
originale del framework (non modificato in questo progetto).

---

## 1. Scopo e ruolo

Il modello del motore, data la coppia richiesta dall'elica in ogni fase di volo, fornisce:

1. corrente, tensione, potenza elettrica e rendimento (fisica elettrica);
2. le costanti caratteristiche del motore (coppia nominale, attrito, resistenza);
3. la massa del motore in fase di dimensionamento.

La coppia richiesta arriva dal modello dell'elica; la tensione e la potenza alimentano i
vincoli su batteria ed ESC; la corrente entra nel bilancio energetico.

---

## 2. Grandezze e convenzioni

```
Kv   [rad/V/s]   costante di velocita' (giri a vuoto per volt)
Kt   [N*m/A]     costante di coppia; in SI Kt = 1/Kv (uguale a Ke)
R    [ohm]       resistenza dell'avvolgimento
Tf   [N*m]       coppia d'attrito (perdite a vuoto)
Tmax [N*m]       coppia massima (di picco)
Tnom [N*m]       coppia nominale (continua)
```

Nota: FAST-UAV usa Kv in unita' SI [rad/V/s]. La relazione con il valore commerciale
[rpm/V] e': Kv[rpm/V] = Kv[rad/V/s] * 60 / (2*pi).

---

## 3. Modello elettrico

Date la coppia meccanica T e la velocita' angolare omega del motore in una fase, il
modello calcola le grandezze elettriche in forma chiusa:

```
I = (T + Tf) * Kv                [A]   corrente (proporzionale alla coppia totale)
U = R * I + omega / Kv           [V]   tensione (caduta ohmica + forza controelettromotrice)
P_el = U * I                     [W]   potenza elettrica assorbita
eta  = (T * omega) / (U * I)     [-]   rendimento (meccanica / elettrica)
```

Con eventuale riduttore (rapporto N_red):
```
T_mot = Q_elica / N_red          coppia al motore
omega_mot = omega_elica * N_red  velocita' al motore
```

Il modello elettrico e' esatto (nessuna riscalatura): dipende solo dalle costanti del
motore (Kv, R, Tf) e dal punto di funzionamento (T, omega).

---

## 4. Costanti caratteristiche (dimensionamento)

Le costanti del motore sono ricavate per leggi di scala a partire da un motore di
riferimento, in funzione della coppia massima Tmax (variabile dimensionante) e di Kv:

```
Coppia nominale:   Tnom = Tnom_ref * (Tmax / Tmax_ref)
Coppia d'attrito:  Tf   = Tf_ref  * (Tmax / Tmax_ref)^(3/3.5)
Resistenza:        R    = R_ref   * (Tmax / Tmax_ref)^(-5/3.5) * (Kv / Kv_ref)^(-2)
```

Motore di riferimento (dal componente DJI M600):
Tmax_ref = 2.817 N*m, Tnom_ref = 2.32 N*m, Tf_ref = 0.03 N*m, R_ref = 0.03 ohm,
Kv_ref = 33.33 rad/V/s.

L'esponente della coppia d'attrito e della resistenza deriva dall'analisi dimensionale
(similitudine geometrica delle macchine elettriche): la coppia, non la potenza, e' la
grandezza che dimensiona la macchina.

---

## 5. Massa

La massa scala con la coppia massima secondo la legge di similitudine:

```
m_mot = m_mot_ref * (Tmax / Tmax_ref)^(3/3.5)
```

con m_mot_ref = 0.575 kg. L'esponente 3/3.5 (~0.857) riflette il fatto che la coppia
cresce piu' rapidamente del volume/massa nelle macchine elettriche geometricamente simili.

---

## 6. Variabili di progetto e vincoli associati

**Variabili di progetto** (coefficienti di sovradimensionamento):
- `motor:torque:k`  — dimensiona Tmax rispetto alla coppia richiesta;
- `motor:speed:k`   — dimensiona Kv.

**Vincoli** (per fase: takeoff, hover, climb, cruise): la coppia richiesta non deve
superare la coppia massima del motore, e la tensione/potenza devono essere compatibili
con batteria ed ESC. Sono presenti anche limiti opzionali su Kv rispetto a Tmax per la
coerenza con i componenti commerciali.

---

## 7. Input / Output

**Input principali:** coppia elica per fase, Kv e Tmax (via variabili di progetto),
costanti di riferimento (`models:propulsion:motor:*:reference`).

**Output principali:**
- `data:propulsion:motor:torque:max`, `:nominal`, `:friction`
- `data:propulsion:motor:resistance`, `:speed:constant` (Kv)
- `data:propulsion:motor:voltage:{fase}`, `:power:{fase}`, `:torque:{fase}`
- `data:weight:propulsion:motor:mass`

---

## 8. Limiti dichiarati

- **Nessun modello termico esplicito:** il modello distingue coppia di picco (Tmax) e
  nominale (Tnom) ma non modella il raffreddamento ne' il tempo sostenibile al picco;
  la dipendenza della coppia specifica dal raffreddamento non e' inclusa.
- **Corrente a vuoto approssimata:** le perdite a vuoto sono rappresentate dalla coppia
  d'attrito Tf; le perdite nel ferro dipendenti dalla frequenza (rilevanti ad altissimi
  giri) non sono modellate separatamente.
- **Costanti costanti:** Kv, R, Tf sono trattate come costanti nel punto di lavoro (non
  variano con temperatura o saturazione magnetica).
- **Scaling da un unico riferimento:** le leggi di scala partono da un motore di
  riferimento; l'accuratezza decresce allontanandosi dalla sua classe.

---

## 9. Riferimenti

- M. Budinger, A. Reysset, A. Ochotorena, S. Delbecq, scaling laws e similarity models
  per il dimensionamento preliminare di droni multirotore.
- Relazione Kv-Kt e modello elettrico BLDC classico (back-EMF, caduta ohmica).
- Algoritmi di sizing BLDC per piccoli UAS con modelli termici ed elettrici.
