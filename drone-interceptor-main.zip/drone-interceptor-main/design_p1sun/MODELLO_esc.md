# Modello dell'ESC (Electronic Speed Controller)

Documento di riferimento del modello dell'ESC in FAST-UAV: dimensionamento in potenza e
tensione, massa, input/output e limiti. Il modello e' quello originale del framework
(non modificato in questo progetto).

---

## 1. Scopo e ruolo

L'ESC e' l'elettronica di potenza che alimenta il motore dalla batteria. Il modello, dato
il punto di funzionamento del motore piu' gravoso (decollo), fornisce:

1. la potenza e la tensione nominali dell'ESC;
2. la massa dell'ESC;
3. i vincoli che garantiscono la compatibilita' con motore e batteria.

Il dimensionamento parte dalla potenza del motore e dalla tensione della batteria.

---

## 2. Dimensionamento in potenza

La potenza nominale dell'ESC e' determinata dalla condizione di massima richiesta
(decollo), riportata alla tensione della batteria:

```
P_esc = k_pesc * (P_mot_to / U_mot_to) * U_bat        [W]
```

dove:
- P_mot_to = potenza del motore al decollo (condizione dimensionante);
- U_mot_to = tensione del motore al decollo;
- U_bat    = tensione della batteria;
- k_pesc   = coefficiente di sovradimensionamento (variabile di progetto).

Il rapporto (P_mot_to / U_mot_to) e' la corrente al decollo; moltiplicata per la tensione
di batteria da' la potenza che l'ESC deve gestire.

---

## 3. Tensione nominale

La tensione nominale dell'ESC deriva dalla tensione di batteria tramite un coefficiente
di progetto, ed e' anche correlata alla potenza per legge di scala:

```
U_esc = k_vesc * U_bat                          [V]   (relazione con la batteria)
U_esc = U_esc_ref * (P_esc / P_esc_ref)^(1/3)   [V]   (legge di scala su potenza)
```

con k_vesc coefficiente di progetto.

---

## 4. Massa

La massa dell'ESC scala linearmente con la potenza nominale:

```
m_esc = m_esc_ref * (P_esc / P_esc_ref)         [kg]
```

Riferimenti (dal componente DJI M600): m_esc_ref = 0.115 kg, P_esc_ref = 3108 W,
U_esc_ref e efficienza (eta = 0.95) dal medesimo riferimento.

---

## 5. Efficienza

Il rendimento dell'ESC e' trattato come costante:

```
eta_esc = eta_esc_ref = 0.95
```

Entra nei bilanci di potenza (la potenza assorbita dalla batteria e' P_motore / eta_esc).

---

## 6. Vincoli

Per ogni fase di volo (decollo, salita, crociera) la potenza dell'ESC deve superare
quella richiesta dal motore, e la tensione deve essere compatibile con la batteria:

```
g_power_fase : (P_esc - P_esc_richiesta_fase) / P_esc >= 0
g_voltage    : (U_esc - U_bat) / U_esc >= 0
```

Inoltre, limiti di tensione da regressione statistica sul database (coerenza con i
componenti reali):

```
U_hat = 1.84 * P_esc^0.36                 [V]   tensione tipica per quella potenza
U_min = U_hat + k * eps_low                     (percentile inferiore dell'errore)
U_max = U_hat + k * eps_up                       (percentile superiore)
g_vmin : (U_esc - U_min) / U_esc >= 0
g_vmax : (U_max - U_esc) / U_esc >= 0
```

dove k = 1 + tolleranza/100 (tolleranza impostabile via input).

---

## 7. Variabili di progetto

- `esc:power:k`   — coefficiente di sovradimensionamento sulla potenza (k_pesc);
- `esc:voltage:k` — coefficiente sulla tensione (k_vesc).

---

## 8. Input / Output

**Input principali:** P_mot_to, U_mot_to (dal motore), U_bat (dalla batteria),
coefficienti di progetto, costanti di riferimento (`models:propulsion:esc:*:reference`).

**Output principali:**
- `data:propulsion:esc:power:max`
- `data:propulsion:esc:voltage`
- `data:propulsion:esc:efficiency:estimated`
- `data:weight:propulsion:esc:mass`

---

## 9. Limiti dichiarati

- **Efficienza costante:** eta = 0.95 fisso, non variabile col punto di lavoro
  (corrente, tensione, temperatura);
- **Nessun modello termico:** non e' modellata la dissipazione ne' il tempo sostenibile
  alla potenza di picco;
- **Massa lineare con la potenza:** relazione semplice, calibrata sul componente di
  riferimento; l'accuratezza decresce allontanandosi dalla sua classe;
- **Limiti di tensione statistici:** i limiti U_min/U_max derivano da una regressione
  sul database, non da un modello fisico dell'ESC.

---

## 10. Riferimenti

- M. Budinger, S. Delbecq et al., scaling laws e similarity models per il dimensionamento
  preliminare di droni multirotore (base del framework).
