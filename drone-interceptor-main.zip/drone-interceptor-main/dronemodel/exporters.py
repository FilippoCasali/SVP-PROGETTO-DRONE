"""
dronemodel.exporters — dal Drone ai formati dei simulatori. (STUB da riempire)
"""
def to_usd(drone, path):      # Isaac Sim: rigid body + massa/inerzia + attuatori
    raise NotImplementedError("USD exporter: TODO")
def to_sdf(drone, path):      # Gazebo/SITL: link/inerzie + plugin motori (kf,km)
    raise NotImplementedError("SDF exporter: TODO")
def to_px4_params(drone, path):  # PX4/ArduPilot: airframe + mixing + thrust curve
    raise NotImplementedError("PX4/ArduPilot params: TODO")
