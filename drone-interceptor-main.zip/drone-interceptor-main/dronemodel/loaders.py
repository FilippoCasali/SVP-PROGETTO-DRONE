"""
dronemodel.loaders — factory dal dimensionamento FAST-UAV.

Legge l'output XML del sizing e costruisce un Drone. La disposizione (posizioni
dei rotori) e' assunta X-quad dai dati geometrici finche' FAST-UAV non espone un
modulo layout dedicato.
"""
from __future__ import annotations
import numpy as np
import fastoad.api as oad

from dronemodel.components import Propeller, Motor, Battery, Body, RotorUnit
from dronemodel.core import PointMass
from dronemodel.drone import Drone

PID = "multirotor"


def from_fastuav(xml_path: str) -> Drone:
    df = oad.DataFile(xml_path)
    n = {v.name: v for v in df}

    def g(k, default=None):
        v = n.get(k)
        if v is None:
            return default
        val = v.value
        arr = np.atleast_1d(np.array(val, dtype=float))
        return arr if arr.size > 1 else float(arr[0])

    P = f"data:propulsion:{PID}:"
    N = int(g(P + "propeller:number"))
    D = g(P + "propeller:diameter")
    beta = g(P + "propeller:beta")
    ct = g(P + "propeller:Ct:dynamic:polynomial")
    cp = g(P + "propeller:Cp:dynamic:polynomial")
    m_motor = g("data:weight:propulsion:" + PID + ":motor:mass")
    m_prop = g("data:weight:propulsion:" + PID + ":propeller:mass")
    Kv = g(P + "motor:speed:constant")
    R = g(P + "motor:resistance")
    Tf = g(P + "motor:torque:friction")
    Tmax = g(P + "motor:torque:max")
    arm = g("data:geometry:arms:length")

    # --- layout X-quad: rotori a 'arm' dal centro, a 45/135/... gradi, z=0 ---
    rotors = []
    for i in range(N):
        ang = np.pi / 4 + i * (2 * np.pi / N)
        pos = np.array([arm * np.cos(ang), arm * np.sin(ang), 0.0])
        spin = 1 if i % 2 == 0 else -1
        prop = Propeller(name=f"prop{i}", mass=m_prop, position=pos,
                         diameter=D, beta=beta, ct_poly=ct, cp_poly=cp)
        mot = Motor(name=f"motor{i}", mass=m_motor, position=pos,
                    Kv=Kv, R=R, Tf=Tf, Tmax=Tmax)
        rotors.append(RotorUnit(motor=mot, propeller=prop, position=pos, spin=spin))

    battery = Battery(
        name="battery",
        mass=g("data:weight:propulsion:" + PID + ":battery:mass"),
        position=np.zeros(3),
        V_nominal=g(P + "battery:voltage"),
        capacity=g(P + "battery:capacity"),
        R_int=g(P + "battery:resistance", 0.0),   # 0 finche' non modelliamo il sag in fastuav
    )

    body = Body(
        name="body", mass=0.0, position=np.zeros(3),
        length=g("data:geometry:body:length", 0.6),
        diameter=g("optimization:variables:geometry:body:diameter", 0.1),
        fineness=g("data:geometry:body:fineness"),
        S_front=g("data:geometry:projected_area:front"),
        S_top=g("data:geometry:projected_area:top"),
    )

    extra = [
        PointMass(name="payload", mass=g("mission:sizing:payload:mass"), position=np.zeros(3)),
        PointMass(name="avionics", mass=g("data:weight:misc:mass"), position=np.zeros(3)),
    ]
    return Drone(rotors=rotors, battery=battery, body=body, extra=extra)
