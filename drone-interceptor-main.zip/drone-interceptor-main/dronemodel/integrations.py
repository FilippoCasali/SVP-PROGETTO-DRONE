"""
dronemodel.integrations — aggancio ai simulatori a runtime. (STUB da riempire)

pegasus_backend: implementa il 'custom thrust/drag model' di Pegasus chiamando
                 drone.total_wrench() a ogni step (PhysX fa il 6-DOF).
ardupilot_json:  loop backend JSON di ArduPilot SITL (riceve stato, integra 6-DOF
                 con drone.total_wrench(), ritorna sensori).
"""
def pegasus_thrust_model(drone):
    raise NotImplementedError("Pegasus backend: TODO")
def ardupilot_json_backend(drone, host="127.0.0.1", port=9002):
    raise NotImplementedError("ArduPilot JSON backend: TODO")
