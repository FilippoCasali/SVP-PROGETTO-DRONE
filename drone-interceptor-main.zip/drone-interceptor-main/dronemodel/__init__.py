"""
dronemodel — digital twin modulare del drone (Python puro + numpy).

Costruisce un modello fisico a componenti (con fisiche componibili) a partire dal
dimensionamento FAST-UAV, e lo espone a simulatori (Isaac Sim/Pegasus, SITL) via
metodi di forza istantanea (runtime) o esportatori (SDF/USD/param).

Dipendenza a senso unico: dronemodel -> fastuav.physics.
"""
from dronemodel.drone import Drone
from dronemodel.loaders import from_fastuav

__all__ = ["Drone", "from_fastuav"]
