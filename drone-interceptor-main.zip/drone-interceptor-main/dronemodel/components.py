"""
dronemodel.components — componenti concreti + le loro fisiche (Effect).

Ogni Effect delega a fastuav.physics (nucleo condiviso col dimensionamento):
non si duplica fisica.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np

from fastuav.physics import (
    MotorPerformanceModel,
    PropellerAerodynamicsModel,
    MultirotorFlightModel,
)
from dronemodel.core import Component, Contribution


# ============================ COMPONENTI ============================

@dataclass
class Propeller(Component):
    diameter: float = 0.0          # [m]
    beta: float = 0.0              # pitch/diameter
    n_blades: int = 2
    ct_poly: np.ndarray = field(default_factory=lambda: np.zeros(12))
    cp_poly: np.ndarray = field(default_factory=lambda: np.zeros(12))

    def coeffs(self, J, alpha):
        return PropellerAerodynamicsModel.aero_coefficients_incidence(
            self.beta, J, alpha, n_blades=self.n_blades,
            ct_model=self.ct_poly, cp_model=self.cp_poly,
        )

    def thrust_torque(self, omega, v_axial, alpha, rho):
        """omega [rad/s], v_axial [m/s] lungo l'asse elica -> (T [N], Q [N*m])."""
        n = omega / (2 * np.pi)                       # giri/s
        J = v_axial / (n * self.diameter) if n > 1e-6 else 0.0
        ct, cp = self.coeffs(J, alpha)
        T = ct * rho * n**2 * self.diameter**4
        P = cp * rho * n**3 * self.diameter**5
        Q = P / omega if omega > 1e-6 else 0.0
        return T, Q


@dataclass
class Motor(Component):
    Kv: float = 0.0                # [rad/V/s]
    R: float = 0.0                 # [ohm]
    Tf: float = 0.0                # coppia d'attrito [N*m]
    Tmax: float = 0.0              # [N*m]
    tau: float = 0.02              # costante di tempo (lag) [s]

    def electrics(self, torque, omega):
        """(I [A], U [V], P_el [W], eta) dal modello elettrico di fastuav."""
        I = MotorPerformanceModel.current(torque, self.Tf, self.Kv)
        U = MotorPerformanceModel.voltage(I, omega, self.R, self.Kv)
        P = MotorPerformanceModel.power(U, I)
        eta = MotorPerformanceModel.efficiency(U, I, torque, omega) if omega > 1e-6 else 0.0
        return I, U, P, eta

    def omega_dot(self, omega, omega_cmd):
        """dinamica di primo ordine (spin-up/down)."""
        return (omega_cmd - omega) / self.tau


@dataclass
class Battery(Component):
    V_nominal: float = 0.0         # [V]
    capacity: float = 0.0          # [A*s]
    R_int: float = 0.0             # resistenza interna [ohm] (per il sag) -- 0 = ideale
    soc: float = 1.0               # stato di carica [0..1]

    def terminal_voltage(self, current):
        """sag: V = V_ocv(soc) - I*R_int. (V_ocv lineare semplice per ora.)"""
        v_ocv = self.V_nominal * (0.9 + 0.1 * self.soc)   # placeholder OCV(soc)
        return v_ocv - current * self.R_int

    def drain(self, current, dt):
        if self.capacity > 0:
            self.soc = max(0.0, self.soc - current * dt / self.capacity)
        return self.soc


@dataclass
class Body(Component):
    length: float = 0.0            # [m]
    diameter: float = 0.0          # [m]
    fineness: float = 0.0          # L/d
    S_front: float = 0.0           # [m2]
    S_top: float = 0.0             # [m2]

    def drag_cd0(self, V, rho, nu):
        return MultirotorFlightModel.body_cd0(self.S_front, self.fineness, V, rho, nu)


@dataclass
class RotorUnit:
    """Motore + elica a una posizione, con verso di rotazione (per lo yaw)."""
    motor: Motor
    propeller: Propeller
    position: np.ndarray                 # [m] body frame
    spin: int = 1                        # +1 CCW / -1 CW

    @property
    def mass(self):
        return self.motor.mass + self.propeller.mass
