"""
dronemodel.core — mattoni base del digital twin.

Pattern a COMPOSIZIONE: un Component ha massa+posizione+geometria e una lista di
Effect (fisiche). Ogni Effect, dato lo stato, produce un Contribution (forze/coppie
+ derivate di stato). Piu' fisiche per lo stesso componente = piu' Effect nella lista.
Multi-fidelita' = sostituisci un Effect con uno diverso.

Dipendenza a senso unico: dronemodel -> fastuav.physics (mai il contrario).
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable
import numpy as np


@dataclass
class Contribution:
    """Contributo fisico di un Effect: forza+coppia (body frame) e derivate di stato extra."""
    force: np.ndarray = field(default_factory=lambda: np.zeros(3))    # [N] body frame
    torque: np.ndarray = field(default_factory=lambda: np.zeros(3))   # [N*m] body frame
    state_dot: dict = field(default_factory=dict)                      # es. {"omega": dω/dt}
    info: dict = field(default_factory=dict)                           # diagnostica (I, U, eta...)

    def __add__(self, other: "Contribution") -> "Contribution":
        sd = {**self.state_dot, **other.state_dot}
        return Contribution(self.force + other.force, self.torque + other.torque,
                            sd, {**self.info, **other.info})

    @staticmethod
    def zero() -> "Contribution":
        return Contribution()


@runtime_checkable
class Effect(Protocol):
    """Una fisica applicata a un componente. Delega i calcoli a fastuav.physics."""
    def contribute(self, comp: "Component", state: dict, ctx: dict) -> Contribution: ...


@dataclass
class Component:
    """
    Mattone fisico: massa, posizione (body frame), geometria, e le fisiche (effects).
    'state' locale (es. rpm del rotore) vive in un dict passato a runtime.
    """
    name: str
    mass: float = 0.0                                          # [kg]
    position: np.ndarray = field(default_factory=lambda: np.zeros(3))  # [m] rispetto a origine body
    inertia_local: np.ndarray = field(default_factory=lambda: np.zeros((3, 3)))  # [kg m2] attorno al CG proprio
    volume: float = 0.0                                        # [m3]
    effects: list = field(default_factory=list)                # list[Effect]

    def evaluate(self, state: dict, ctx: dict) -> Contribution:
        c = Contribution.zero()
        for e in self.effects:
            c = c + e.contribute(self, state, ctx)
        return c


@dataclass
class PointMass(Component):
    """Massa concentrata senza fisica (payload, avionica, struttura)."""
    pass


def mass_properties(components: list[Component]):
    """
    CG e tensore d'inerzia dell'insieme, attorno al CG globale (teorema di Huygens-Steiner).
    Ritorna (mass_tot [kg], cg [3], inertia [3x3]).
    """
    m = np.array([c.mass for c in components])
    M = float(m.sum())
    pos = np.array([c.position for c in components])
    cg = (m[:, None] * pos).sum(axis=0) / M
    I = np.zeros((3, 3))
    for c in components:
        r = c.position - cg
        # parallel axis: I += m (r·r I3 - r⊗r) + I_local
        I += c.inertia_local + c.mass * (np.dot(r, r) * np.eye(3) - np.outer(r, r))
    return M, cg, I
