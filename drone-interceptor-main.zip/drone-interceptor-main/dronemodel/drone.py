"""
dronemodel.drone — l'assemblatore.

Mette insieme i componenti, calcola le proprieta' di massa (CG, inerzia) e fornisce
i metodi RUNTIME (forze istantanee) che un simulatore chiama a ogni timestep.
Il simulatore (Isaac/PhysX, o un backend Python per SITL) integra il 6-DOF.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np
from scipy.constants import g

from dronemodel.core import Component, mass_properties
from dronemodel.components import RotorUnit, Battery, Body


@dataclass
class Drone:
    rotors: list[RotorUnit] = field(default_factory=list)
    battery: Battery = None
    body: Body = None
    extra: list[Component] = field(default_factory=list)   # payload, avionica, struttura
    rho: float = 1.225                                     # densita' aria [kg/m3]
    nu: float = 1.46e-5                                    # viscosita' cinematica [m2/s]

    # ---------- componenti come lista piatta (per le proprieta' di massa) ----------
    def _all_components(self) -> list[Component]:
        comps = list(self.extra)
        if self.battery: comps.append(self.battery)
        if self.body: comps.append(self.body)
        for r in self.rotors:
            comps.append(Component(name=r.motor.name, mass=r.mass, position=r.position))
        return comps

    # ---------- proprieta' statiche (per export + inerzia) ----------
    @property
    def mass_properties(self):
        return mass_properties(self._all_components())

    @property
    def mass(self):  return self.mass_properties[0]
    @property
    def cg(self):    return self.mass_properties[1]
    @property
    def inertia(self):  return self.mass_properties[2]

    # ---------- runtime: forze istantanee (per il simulatore) ----------
    def total_wrench(self, v_body: np.ndarray, omegas: list[float], dt: float = 0.0):
        """
        Forza e coppia totali nel body frame, dato lo stato di volo e i giri dei rotori.
        Modello: rotori assiali lungo +z body; drag corpo lungo la velocita'.
        Ritorna (F[3], tau[3], info).
        """
        F = np.zeros(3); tau = np.zeros(3); info = {"rotors": []}
        speed = float(np.linalg.norm(v_body))
        v_axial = float(v_body[2])  # componente lungo l'asse rotori (semplificazione)

        current_tot = 0.0
        for r, w in zip(self.rotors, omegas):
            T, Q = r.propeller.thrust_torque(w, v_axial, alpha=np.pi/2, rho=self.rho)
            F[2] += T                                   # spinta lungo +z body
            # coppia: reazione di imbardata + momento della spinta rispetto al CG
            tau[2] += -r.spin * Q                       # reaction torque (yaw)
            arm = r.position - self.cg
            tau += np.cross(arm, np.array([0, 0, T]))   # roll/pitch dai bracci
            I, U, P, eta = r.motor.electrics(Q, w)
            current_tot += I
            info["rotors"].append({"T": T, "Q": Q, "I": I, "U": U, "eta": eta})

        # drag del corpo (opposto alla velocita')
        if self.body and speed > 1e-6:
            cd0 = self.body.drag_cd0(speed, self.rho, self.nu)
            drag = 0.5 * self.rho * cd0 * self.body.S_front * speed**2
            F += -drag * (v_body / speed)

        # batteria: sag + scarica
        if self.battery:
            info["V_batt"] = self.battery.terminal_voltage(current_tot)
            info["I_batt"] = current_tot
            if dt > 0: self.battery.drain(current_tot, dt)
        return F, tau, info

    # ---------- validazione ----------
    def check_hover(self):
        """Verifica la capacita' di hover: giri richiesti, corrente, throttle, T/W max."""
        W = self.mass * g
        T_req = W / len(self.rotors)
        r = self.rotors[0]
        # risolvi omega per T_req in hover (v_axial=0, alpha=pi/2)
        from scipy.optimize import brentq
        f = lambda w: r.propeller.thrust_torque(w, 0.0, np.pi/2, self.rho)[0] - T_req
        w_hover = brentq(f, 1.0, 1.0e4)
        _, Q = r.propeller.thrust_torque(w_hover, 0.0, np.pi/2, self.rho)
        I, U, P, eta = r.motor.electrics(Q, w_hover)
        w_max = r.motor.Kv * self.battery.V_nominal
        T_max = r.propeller.thrust_torque(w_max, 0.0, np.pi/2, self.rho)[0]
        return {
            "mass_kg": self.mass, "weight_N": W,
            "omega_hover_rads": w_hover, "throttle_hover": w_hover / w_max,
            "I_hover_A": I, "U_hover_V": U, "eta_hover": eta,
            "TW_max": T_max * len(self.rotors) / W,
        }
