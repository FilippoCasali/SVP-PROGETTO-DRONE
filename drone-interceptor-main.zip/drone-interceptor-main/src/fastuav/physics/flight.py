"""
UAV flight models — pure physics (drag, lift, thrust/attitude balance).
"""

import numpy as np
from scipy.constants import g
from scipy.optimize import minimize


class MultirotorFlightModel:
    """
    Flight model for multirotor (pure static methods).
    """

    @staticmethod
    def body_cd0(S_front, fineness, V, rho_air, nu, k_shape=0.75):
        """
        CD0 del corpo via component build-up (metodo form-factor, Raymer/Hoerner),
        riferito all'area FRONTALE. Fisico e Reynolds-dipendente, adatto a una
        fusoliera snella (proiettile).

        S_front  : area frontale [m2]
        fineness : allungamento L/d [-]
        V, rho, nu : velocita' [m/s], densita' [kg/m3], viscosita' cinematica [m2/s]
        """
        d = np.sqrt(4 * S_front / np.pi)      # diametro equivalente
        L = fineness * d                      # lunghezza
        S_wet = np.pi * d * L * k_shape       # area bagnata (corpo di rivoluzione)
        Re = max(V * L / nu, 1.0e4)           # Reynolds (guardia per V bassi)
        Cf = 0.455 / (np.log10(Re)) ** 2.58   # attrito turbolento (flat plate)
        FF = 1.0 + 60.0 / fineness**3 + fineness / 400.0  # form factor corpo
        return Cf * FF * S_wet / S_front      # CD0 riferito al frontale

    @staticmethod
    def parasitic_drag(V, alpha, rho_air, N,
                       b_arm, h_arm, L_arm, d_mot, L_mot,
                       Cd_arm=1.2, Cd_mot=1.0):
        """
        Drag parassita di BRACCI e MOTORI esposti (corpi tozzi), oltre alla fusoliera.
        Aree per-direzione corrette e pesate con l'assetto alpha (pi/2=hover, 0=volo veloce):
          - braccio flat-plate: frontale b*h (dash) | pianta L_arm*b (hover)
          - motore (cilindro asse verticale): laterale d_mot*L_mot (dash) | disco pi*d_mot^2/4 (hover)
        Con b_arm=0 e d_mot=0 -> drag nullo (retrocompatibile).
        """
        s, c = np.sin(alpha), np.cos(alpha)
        # area di riferimento per-corpo che ruota con l'assetto (come la fusoliera)
        S_arm = (L_arm * b_arm) * s + (b_arm * h_arm) * c          # hover | dash
        S_mot = (np.pi * d_mot**2 / 4.0) * s + (d_mot * L_mot) * c  # disco | laterale
        D = 0.5 * rho_air * V**2 * N * (Cd_arm * S_arm + Cd_mot * S_mot)
        return D

    @staticmethod
    def get_drag(V, alpha, S_front, S_top, C_D, rho_air):
        """
        Computes body drag from drag coefficient, reference surfaces and velocity
        """
        S_ref = S_top * np.sin(alpha) + S_front * np.cos(alpha)  # [m2] reference area
        drag = 0.5 * rho_air * C_D * S_ref * V**2  # [N] drag
        return drag

    @staticmethod
    def get_lift(V, alpha, S_top, C_L0, rho_air):
        """
        Computes body lift from lift coefficient, reference surface and velocity.
        Derived from a flat plate model.
        """
        S_ref = S_top * np.sin(alpha)  # [m2] reference area
        C_L = C_L0 * np.sin(
            -2 * alpha
        )  # [-] flat plate model (minus in front of alpha because of angle definition)
        lift = 0.5 * rho_air * C_L * S_ref * V**2  # [N] lift
        return lift

    @staticmethod
    def get_angle_of_attack(m_uav, V, RoC, S_front, S_top, C_D, C_L0, rho_air):
        """
        Computes angle of attack to maintain flight path
        """
        # flight path angle [rad]
        if V != 0.0 and V > RoC:
            theta = np.arcsin(RoC / V)
        else:
            alpha = theta = np.pi / 2
            return alpha

        def func(x):
            drag = MultirotorFlightModel.get_drag(V, x, S_front, S_top, C_D, rho_air)  # [N] drag
            lift = MultirotorFlightModel.get_lift(V, x, S_top, C_L0, rho_air)  # [N] lift
            weight = m_uav * g  # [N] weight
            res = np.tan(abs(x - theta)) - (drag * np.cos(theta) + lift * np.sin(theta)) / (
                weight + drag * np.sin(theta) - lift * np.cos(theta)
            )  # [-] equilibrium residual
            return res**2

        bnds = ((0.0, np.pi / 2),)
        res = minimize(func, (np.pi / 4), bounds=bnds, method="SLSQP")  # [rad] angle of attack
        alpha = res.x if res.success else np.pi / 2
        return alpha

    @staticmethod
    def get_thrust(m_uav, V, RoC, alpha, S_front, S_top, C_D, C_L0, rho_air):
        """
        Computes thrust to maintain flight path
        """
        # flight path angle [rad]
        if V != 0.0 and V >= RoC:
            theta = np.arcsin(RoC / V)
        else:
            theta = np.pi / 2

        weight = m_uav * g  # [N] weight
        lift = MultirotorFlightModel.get_lift(V, alpha, S_top, C_L0, rho_air)  # [N] lift
        drag = MultirotorFlightModel.get_drag(V, alpha, S_front, S_top, C_D, rho_air)  # [N] drag
        thrust = (
            (weight + drag * np.sin(theta) - lift * np.cos(theta)) ** 2
            + (drag * np.cos(theta) + lift * np.sin(theta)) ** 2
        ) ** (1 / 2)  # [N] total thrust requirement
        return thrust


class FixedwingFlightModel:
    """
    Flight model for fixed wings (pure static methods).
    """

    @staticmethod
    def get_angle_of_attack():
        """
        Computes angle of attack to maintain flight path
        """
        alpha = (
            np.pi / 2
        )  # [rad] Rotor disk Angle of Attack (assumption: axial flight TODO: estimate trim?)
        return alpha

    @staticmethod
    def get_thrust(m_uav, V, RoC, WS, K, CD0, rho_air):
        """
        Computes thrust to maintain flight path
        """
        q = 0.5 * rho_air * V**2  # [Pa] dynamic pressure
        TW = RoC / V + q * CD0 / WS + K / q * WS  # thrust-to-weight ratio in climb conditions [-]
        thrust = TW * m_uav * g  # [N] total thrust requirement
        return thrust
