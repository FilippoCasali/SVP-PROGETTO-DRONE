"""
Motor performance — pure physics (electrical model).
"""

import numpy as np  # noqa: F401  (kept for API parity / future use)


class MotorPerformanceModel:
    """
    Motor model for performances calculation (pure static methods).
    """

    @staticmethod
    def torque(Q_pro, N_red):
        T_mot = Q_pro / N_red  # [N.m] motor torque with reduction
        return T_mot

    @staticmethod
    def speed(W_pro, N_red):
        W_mot = W_pro * N_red  # [rad/s] Motor speed with reduction
        return W_mot

    @staticmethod
    def current(T_mot, Tf_mot, Kv):
        I_mot = (T_mot + Tf_mot) * Kv  # [A] Current of the motor
        return I_mot

    @staticmethod
    def voltage(I_mot, W_mot, R, Kv):
        U_mot = R * I_mot + W_mot / Kv  # [V] Voltage of the motor
        return U_mot

    @staticmethod
    def power(U_mot, I_mot):
        P_mot_el = U_mot * I_mot  # [W] electrical power
        return P_mot_el

    @staticmethod
    def efficiency(U_mot, I_mot, T_mot, W_mot):
        P_mot_el = U_mot * I_mot
        P_mot_mech = T_mot * W_mot
        eta_mot = P_mot_mech / P_mot_el
        return eta_mot
