"""
fastuav.physics — FISICA PURA (numpy, niente OpenMDAO).

Nucleo condiviso: le classi di modello fisico (metodi statici) usate sia dai
componenti OpenMDAO di fastuav (dimensionamento) sia da dronemodel (simulazione).
Nessuna dipendenza da OpenMDAO o dal pool di variabili -> richiamabile ovunque,
a qualsiasi stato (rpm, velocita', quota).
"""
from fastuav.physics.motor import MotorPerformanceModel
from fastuav.physics.propeller import PropellerAerodynamicsModel
from fastuav.physics.flight import MultirotorFlightModel

__all__ = [
    "MotorPerformanceModel",
    "PropellerAerodynamicsModel",
    "MultirotorFlightModel",
]
