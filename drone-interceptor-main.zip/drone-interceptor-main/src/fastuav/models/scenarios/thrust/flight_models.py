"""
UAV flight models for thrust calculations.

Fisica pura estratta in fastuav.physics.flight (re-export per compatibilita').
I componenti OpenMDAO importano queste classi da qui come prima.
"""

from fastuav.physics.flight import (  # noqa: F401
    MultirotorFlightModel,
    FixedwingFlightModel,
)
