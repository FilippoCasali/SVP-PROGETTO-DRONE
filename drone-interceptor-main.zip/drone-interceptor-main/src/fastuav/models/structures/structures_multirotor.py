"""
Multirotor Structures
"""

import fastoad.api as oad
import numpy as np
import openmdao.api as om

from fastuav.constants import MR_PROPULSION


@oad.RegisterOpenMDAOSystem("fastuav.structures.multirotor")
class Structures(om.Group):
    """
    Group containing the airframe structural analysis and weights calculation.

    Opzione 'frame_type':
      - "tube" (default): bracci a TUBO circolare cavo (modello originale). Flessione
        classica di mensola, sezione circolare.
      - "flat_plate": frame PIANO (bracci a sezione rettangolare piatta, tipo racer
        FPV / lastra in carbonio CNC). Piu' rigido nel piano, piu' debole fuori dal
        piano (dove agisce la spinta) -> spessore dominato dalla flessione verticale.
    """

    def initialize(self):
        self.options.declare("frame_type", default="tube", values=["tube", "flat_plate"])

    def setup(self):
        self.add_subsystem(
            "arms", ArmsWeight(frame_type=self.options["frame_type"]), promotes=["*"]
        )
        self.add_subsystem("body", BodyWeight(), promotes=["*"])


class ArmsWeight(om.ExplicitComponent):
    """
    Computes arms weight (tube or flat-plate frame).
    """

    def initialize(self):
        self.options.declare("propulsion_id", default=MR_PROPULSION, values=[MR_PROPULSION])
        self.options.declare("frame_type", default="tube", values=["tube", "flat_plate"])

    def setup(self):
        propulsion_id = self.options["propulsion_id"]

        self.add_input("optimization:variables:structures:arms:diameter:k", val=np.nan, units=None)
        self.add_input("data:geometry:arms:number", val=np.nan, units=None)
        self.add_input("data:geometry:arms:prop_per_arm", val=np.nan, units=None)
        self.add_input("data:geometry:arms:length", val=np.nan, units="m")
        self.add_input("data:weight:arms:density", val=np.nan, units="kg/m**3")
        self.add_input("data:structures:arms:stress:max", val=np.nan, units="N/m**2")
        self.add_input(
            "data:propulsion:%s:propeller:thrust:takeoff" % propulsion_id,
            val=np.nan,
            units="N",
        )
        # fattore di sicurezza (default 1.0 = comportamento originale)
        self.add_input("models:structures:arms:safety_factor", val=1.0, units=None)
        if self.options["frame_type"] == "flat_plate":
            # rapporto larghezza/spessore della sezione rettangolare (b/h)
            self.add_input("data:structures:arms:aspect_ratio", val=5.0, units=None)
        # --- parametri per deflessione e analisi modale (vincoli opzionali) ---
        self.add_input("models:structures:arms:youngs_modulus", val=70e9, units="N/m**2")  # E (carbonio ~70 GPa)
        self.add_input("models:structures:arms:deflection_ratio:max", val=1.0, units=None)  # delta/L max (1.0 = inattivo)
        self.add_input("models:structures:arms:modal_margin", val=0.0, units=None)  # f_arm >= margin*f_rot (0 = inattivo)
        self.add_input("data:weight:propulsion:%s:motor:mass" % propulsion_id, val=0.1, units="kg")
        self.add_input("data:weight:propulsion:%s:propeller:mass" % propulsion_id, val=0.01, units="kg")
        self.add_input("data:propulsion:%s:motor:speed:takeoff" % propulsion_id, val=1000.0, units="rad/s")

        self.add_output("data:structures:arms:diameter:outer", units="m", lower=0.0)
        self.add_output("data:structures:arms:diameter:inner", units="m", lower=0.0)
        self.add_output("data:weight:airframe:arms:mass", units="kg")
        # diagnostici + vincoli deflessione/modale
        self.add_output("data:structures:arms:deflection:tip", units="m")
        self.add_output("data:structures:arms:frequency:natural", units="Hz")
        self.add_output("optimization:constraints:structures:arms:deflection", units=None)
        self.add_output("optimization:constraints:structures:arms:modal", units=None)
        if self.options["frame_type"] == "flat_plate":
            self.add_output("data:structures:arms:plate:width", units="m", lower=0.0)
            self.add_output("data:structures:arms:plate:thickness", units="m", lower=0.0)

    def setup_partials(self):
        # Finite difference all partials.
        self.declare_partials("*", "*", method="fd")

    def compute(self, inputs, outputs):
        propulsion_id = self.options["propulsion_id"]
        Narm = inputs["data:geometry:arms:number"]
        Npro_arm = inputs["data:geometry:arms:prop_per_arm"]
        Larm = inputs["data:geometry:arms:length"]
        rho = inputs["data:weight:arms:density"]
        Sigma_max = inputs["data:structures:arms:stress:max"]
        F_pro_to = inputs["data:propulsion:%s:propeller:thrust:takeoff" % propulsion_id]
        FoS = inputs["models:structures:arms:safety_factor"]

        # sforzo ammissibile ridotto dal fattore di sicurezza
        Sigma_adm = Sigma_max / FoS

        if self.options["frame_type"] == "flat_plate":
            # --- FRAME PIANO: sezione rettangolare b (largh.) x h (spess.) ---
            # la spinta flette il braccio FUORI dal piano (asse debole, ~h^3):
            #   sigma = 6 F L / (b h^2),  con b = AR*h  ->  h = (6 F L / (AR sigma))^(1/3)
            AR = inputs["data:structures:arms:aspect_ratio"]
            M_bend = F_pro_to * Npro_arm * Larm            # momento flettente
            h = (6.0 * M_bend / (AR * Sigma_adm)) ** (1.0 / 3.0)  # spessore
            b = AR * h                                      # larghezza
            Marms = b * h * Larm * rho * Narm               # sezione piena rettangolare
            I = b * h**3 / 12.0                             # momento d'inerzia (asse debole)
            outputs["data:structures:arms:plate:width"] = b
            outputs["data:structures:arms:plate:thickness"] = h
            Deq = (4.0 * b * h / np.pi) ** 0.5              # diametro equivalente (compat.)
            outputs["data:structures:arms:diameter:outer"] = Deq
            outputs["data:structures:arms:diameter:inner"] = 0.0
        else:
            # --- TUBO circolare cavo (modello originale) ---
            D_ratio = inputs["optimization:variables:structures:arms:diameter:k"]
            Dout = (F_pro_to * Npro_arm * Larm * 32 / (np.pi * Sigma_adm * (1 - D_ratio**4))) ** (
                1 / 3
            )  # [m] outer diameter of the beam (sized from max thrust)
            Din = D_ratio * Dout                            # [m] inner diameter of the beam
            Marms = np.pi / 4 * (Dout**2 - Din**2) * Larm * rho * Narm
            I = np.pi / 64.0 * (Dout**4 - Din**4)           # momento d'inerzia (tubo)
            outputs["data:structures:arms:diameter:outer"] = Dout
            outputs["data:structures:arms:diameter:inner"] = Din

        outputs["data:weight:airframe:arms:mass"] = Marms

        # --- DEFLESSIONE e MODALE (vincoli, comuni ai due tipi) ---
        E = inputs["models:structures:arms:youngs_modulus"]
        defl_max = inputs["models:structures:arms:deflection_ratio:max"]
        modal_margin = inputs["models:structures:arms:modal_margin"]
        m_tip = (
            inputs["data:weight:propulsion:%s:motor:mass" % propulsion_id]
            + inputs["data:weight:propulsion:%s:propeller:mass" % propulsion_id]
        )  # massa concentrata in punta (motore + elica)
        Omega_max = inputs["data:propulsion:%s:motor:speed:takeoff" % propulsion_id]

        F_tip = F_pro_to * Npro_arm                         # carico in punta
        k_beam = 3.0 * E * I / Larm**3                      # rigidezza mensola [N/m]
        delta = F_tip / k_beam                              # freccia in punta [m]
        f_arm = (1.0 / (2.0 * np.pi)) * np.sqrt(k_beam / max(m_tip, 1e-6))  # freq propria [Hz]
        f_rot = Omega_max / (2.0 * np.pi)                   # freq rotazione max [Hz]

        outputs["data:structures:arms:deflection:tip"] = delta
        outputs["data:structures:arms:frequency:natural"] = f_arm
        # vincolo deflessione: delta/L <= defl_max  (default defl_max=1.0 -> sempre soddisfatto)
        outputs["optimization:constraints:structures:arms:deflection"] = (
            defl_max - delta / Larm
        )
        # vincolo modale: f_arm >= modal_margin * f_rot  (default margin=0 -> soddisfatto)
        outputs["optimization:constraints:structures:arms:modal"] = (
            (f_arm - modal_margin * f_rot) / f_arm
        )


class BodyWeight(om.ExplicitComponent):
    """
    Computes body weight
    """

    def setup(self):
        self.add_input("models:weight:airframe:arms:mass:reference", val=np.nan, units="kg")
        self.add_input("models:weight:airframe:body:mass:reference", val=np.nan, units="kg")
        self.add_input("data:weight:airframe:arms:mass", val=np.nan, units="kg")
        self.add_output("data:weight:airframe:body:mass", units="kg")

    def setup_partials(self):
        # Finite difference all partials.
        self.declare_partials("*", "*", method="fd")

    def compute(self, inputs, outputs):
        Marm_ref = inputs["models:weight:airframe:arms:mass:reference"]
        Mbody_ref = inputs["models:weight:airframe:body:mass:reference"]
        Marms = inputs["data:weight:airframe:arms:mass"]

        Mbody = Mbody_ref * (Marms / Marm_ref)  # [kg] mass of the frame

        outputs["data:weight:airframe:body:mass"] = Mbody
