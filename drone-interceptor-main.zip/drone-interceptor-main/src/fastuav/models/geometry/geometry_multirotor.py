"""
Multirotor Airframe Geometry
"""

import fastoad.api as oad
import numpy as np
import openmdao.api as om

from fastuav.constants import MR_PROPULSION


@oad.RegisterOpenMDAOSystem("fastuav.geometry.multirotor")
class Geometry(om.Group):
    """
    Computes Multi-Rotor geometry
    """

    def initialize(self):
        self.options.declare("propulsion_id", default=MR_PROPULSION, values=[MR_PROPULSION])

    def setup(self):
        propulsion_id = self.options["propulsion_id"]
        self.add_subsystem("arms", ArmsGeometry(propulsion_id=propulsion_id), promotes=["*"])
        # + Body geometry is estimated in the "Scenarios" module instead of here to avoid algebraic loop.
        # See 'ProjectedAreasGuess' class.
        # self.add_subsystem("body", BodyGeometry(), promotes=["*"])
        # vincolo: il volume interno del corpo deve contenere batteria + payload + avionica
        self.add_subsystem(
            "body_volume", BodyVolumeConstraint(propulsion_id=propulsion_id), promotes=["*"]
        )


class BodyVolumeConstraint(om.ExplicitComponent):
    """
    Vincolo: il volume interno della fusoliera deve contenere batteria + payload + avionica.
    constraint >= 0  <=>  V_interno >= V_necessario
    """

    def initialize(self):
        self.options.declare("propulsion_id", default=MR_PROPULSION, values=[MR_PROPULSION])

    def setup(self):
        pid = self.options["propulsion_id"]
        self.add_input("data:geometry:body:volume:internal", val=np.nan, units="m**3")
        self.add_input("data:propulsion:%s:battery:volume" % pid, val=np.nan, units="m**3")
        self.add_input("data:geometry:body:volume:payload", val=400e-6, units="m**3")   # >=400 cm3
        self.add_input("data:geometry:body:volume:avionics", val=200e-6, units="m**3")
        self.add_output("optimization:constraints:geometry:body:volume", units=None)

    def setup_partials(self):
        self.declare_partials("*", "*", method="fd")

    def compute(self, inputs, outputs):
        pid = self.options["propulsion_id"]
        V_int = inputs["data:geometry:body:volume:internal"]
        V_need = (
            inputs["data:propulsion:%s:battery:volume" % pid]
            + inputs["data:geometry:body:volume:payload"]
            + inputs["data:geometry:body:volume:avionics"]
        )
        outputs["optimization:constraints:geometry:body:volume"] = (V_int - V_need) / V_need


class ArmsGeometry(om.ExplicitComponent):
    """
    Computes arms geometry
    """

    def initialize(self):
        self.options.declare("propulsion_id", default=MR_PROPULSION, values=[MR_PROPULSION])

    def setup(self):
        propulsion_id = self.options["propulsion_id"]
        self.add_input(
            "data:propulsion:%s:propeller:diameter" % propulsion_id,
            val=np.nan,
            units="m",
        )
        self.add_input(
            "data:propulsion:%s:propeller:number" % propulsion_id,
            val=np.nan,
            units=None,
        )
        self.add_input(
            "data:propulsion:%s:propeller:is_coaxial" % propulsion_id,
            val=np.nan,
            units=None,
        )
        # margine di clearance tra le eliche (1.0 = eliche che si sfiorano, originale;
        # 1.1-1.15 = gap realistico raccomandato per evitare prop-wash / vibrazioni)
        self.add_input("models:geometry:arms:clearance_factor", val=1.0, units=None)
        self.add_output("data:geometry:arms:prop_per_arm", units=None)
        self.add_output("data:geometry:arms:number", units=None)
        self.add_output("data:geometry:arms:length", units="m", lower=0.0)

    def setup_partials(self):
        # Finite difference all partials.
        self.declare_partials("*", "*", method="fd")

    def compute(self, inputs, outputs):
        propulsion_id = self.options["propulsion_id"]
        Dpro = inputs["data:propulsion:%s:propeller:diameter" % propulsion_id]
        N_pro = inputs["data:propulsion:%s:propeller:number" % propulsion_id]
        is_coaxial = inputs["data:propulsion:%s:propeller:is_coaxial" % propulsion_id]
        k_clear = inputs["models:geometry:arms:clearance_factor"]

        Npro_arm = 1 + is_coaxial
        Narm = N_pro / Npro_arm
        Larm = (
            k_clear * Dpro / 2 / (np.sin(np.pi / Narm))
        )  # [m] length of the arm (clearance_factor * minimum spacing)

        outputs["data:geometry:arms:prop_per_arm"] = Npro_arm
        outputs["data:geometry:arms:number"] = Narm
        outputs["data:geometry:arms:length"] = Larm


class BodyGeometry(om.ExplicitComponent):
    """
    Computes body's top and front areas.
    For now this is a simple duplicate of the projected areas estimates,
    such that no consistency constraint for the projected areas is needed.
    """

    def setup(self):
        self.add_input("data:geometry:projected_area:top", val=np.nan, units="m**2")
        self.add_input("data:geometry:projected_area:front", val=np.nan, units="m**2")
        self.add_output("data:geometry:body:surface:top", units="m**2")
        self.add_output("data:geometry:body:surface:front", units="m**2")

    def setup_partials(self):
        self.declare_partials("*", "*", method="fd")

    def compute(self, inputs, outputs):
        outputs["data:geometry:body:surface:top"] = inputs["data:geometry:projected_area:top"]
        outputs["data:geometry:body:surface:front"] = inputs["data:geometry:projected_area:front"]


class ProjectedAreasGuess(om.ExplicitComponent):
    """
    Body geometry as a SLENDER FUSELAGE: fixed length + diameter (design variable).

    Sostituisce la vecchia stima per scaling-law (aree da M600 scalate su MTOW), che
    dava un corpo tozzo (fineness ~1.8). Qui il corpo e' un proiettile affusolato:
    lunghezza L fissa (= massima consentita), diametro d variabile di progetto scelto
    dall'ottimizzatore. Il diametro minimo che fa entrare tutto (vincolo di volume)
    da' il drag piu' basso. Espone anche fineness e volume interno.
    """

    def setup(self):
        self.add_input("data:geometry:body:length", val=0.6, units="m")  # fissa (= max)
        self.add_input(
            "optimization:variables:geometry:body:diameter", val=0.12, units="m"
        )
        self.add_input("data:geometry:body:fill_factor", val=0.65, units=None)  # riempimento interno
        self.add_output("data:geometry:projected_area:top", units="m**2")
        self.add_output("data:geometry:projected_area:front", units="m**2")
        self.add_output("data:geometry:body:fineness", units=None)
        self.add_output("data:geometry:body:volume:internal", units="m**3")

    def setup_partials(self):
        self.declare_partials("*", "*", method="fd")

    def compute(self, inputs, outputs):
        L = inputs["data:geometry:body:length"]
        d = inputs["optimization:variables:geometry:body:diameter"]
        k_fill = inputs["data:geometry:body:fill_factor"]

        outputs["data:geometry:projected_area:front"] = np.pi * d**2 / 4  # [m2] frontale (cerchio)
        outputs["data:geometry:projected_area:top"] = L * d               # [m2] planform (L x d)
        outputs["data:geometry:body:fineness"] = L / d                    # [-] allungamento
        outputs["data:geometry:body:volume:internal"] = k_fill * (np.pi / 4 * d**2 * L)  # [m3]
