"""
Dash-speed capability constraint for multirotor UAVs (SMOOTH formulation).

FAST-UAV sizes only prescribed climb/cruise speeds; it does NOT verify the maximum
forward speed. This module adds that as a set of SMOOTH, differentiable constraints
suitable for a gradient-based driver (SLSQP).

Idea (no internal search -> clean gradients):
  The propeller rotational speed at the dash, Omega_dash, is promoted to a DESIGN
  VARIABLE. The dash target speed V_dash is a fixed requirement. We then impose, as
  explicit inequality constraints evaluated at (Omega_dash, V_dash):

    g1 thrust  : T(Omega_dash, V_dash) >= T_required(V_dash)      -> reaches the speed
    g2 torque  : Q(Omega_dash)         <= Q_max                   -> motor torque limit
    g3 power   : P(Omega_dash)         <= P_max                   -> motor power limit
    g4 rpm     : Omega_dash            <= Kv * V_batt             -> electrical limit
    g5 advance : J * sin(alpha)        <= 0.95 * J0               -> prop not windmilling
    g6 mach    : Omega_dash * D/2      <= mach_tip_max * a_sound  -> tip compressibility

  If a feasible Omega_dash exists satisfying all six, then V_dash is achievable, i.e.
  V_max >= V_dash. Otherwise the optimizer must grow the propulsion (motor/battery/prop)
  until one exists. All quantities are closed-form and C1 -> no discrete rpm scan, no
  branching, no gradient noise.

  To instead COMPUTE V_max, make V_dash a design variable, maximise it (objective -V_dash)
  and turn g1 into an equality (thrust = drag).

Physics reused from the rest of FAST-UAV for consistency:
  - MultirotorFlightModel        -> level-flight drag / thrust requirement
  - PropellerAerodynamicsModel   -> propeller thrust & power coefficients (incidence)
"""
import numpy as np
import openmdao.api as om
import fastoad.api as oad
from stdatm import Atmosphere

from fastuav.constants import MR_PROPULSION
from fastuav.models.scenarios.thrust.flight_models import MultirotorFlightModel
from fastuav.models.propulsion.motor.performance_analysis import MotorPerformanceModel
from fastuav.models.propulsion.propeller.aerodynamics.surrogate_models import (
    PropellerAerodynamicsModel,
)

_MACH_TIP_MAX = 0.80        # limite di compressibilita' alla punta
_J0_MARGIN = 0.95           # margine sotto l'advance ratio di spinta nulla


@oad.RegisterOpenMDAOSystem("fastuav.performance.max_speed.multirotor")
class MaxSpeedMultirotor(om.Group):
    """Dash-speed capability constraint (multirotor), smooth formulation."""

    def setup(self):
        self.add_subsystem(
            "dash", DashSpeedConstraint(propulsion_id=MR_PROPULSION), promotes=["*"]
        )


class DashSpeedConstraint(om.ExplicitComponent):
    """
    Smooth dash-speed constraints evaluated at the design variable Omega_dash and the
    fixed target V_dash. Outputs six normalised constraints (>= 0 is feasible).
    """

    def initialize(self):
        self.options.declare("propulsion_id", default=MR_PROPULSION)

    def setup(self):
        pid = self.options["propulsion_id"]
        add = self.add_input
        # --- design variable: manetta al dash (in [0.3,1.0]) ---
        # Omega_dash = throttle * Kv*Vbatt (giri max elettrici). throttle>=0.3 -> giri sempre
        # sostanziali (niente windmilling); throttle<=1 -> vincolo rpm automatico.
        add("optimization:variables:propulsion:%s:dash:throttle" % pid, val=0.7, units=None)
        # --- requisito ---
        add("mission:sizing:dash:speed:%s" % pid, val=83.33, units="m/s")  # 300 km/h default
        # --- geometria / massa / aero ---
        add("data:propulsion:%s:propeller:diameter" % pid, val=np.nan, units="m")
        add("data:propulsion:%s:propeller:beta" % pid, val=np.nan, units=None)
        add("data:propulsion:%s:propeller:number" % pid, val=np.nan, units=None)
        add("data:weight:mtow", val=np.nan, units="kg")
        add("data:aerodynamics:%s:CD0" % pid, val=np.nan, units=None)
        add("data:geometry:body:fineness", val=np.nan, units=None)  # per CD0 build-up
        add("data:geometry:projected_area:front", val=np.nan, units="m**2")
        add("data:geometry:projected_area:top", val=np.nan, units="m**2")
        # --- drag parassita bracci+motori (default 0 = solo fusoliera, retrocompatibile) ---
        add("data:structures:arms:plate:width", val=0.0, units="m")       # b (flat_plate)
        add("data:structures:arms:plate:thickness", val=0.0, units="m")   # h
        add("data:geometry:arms:length", val=0.0, units="m")              # L_arm
        add("data:propulsion:%s:motor:length:estimated" % pid, val=0.0, units="m")  # L_mot (d_mot~1.7*L_mot)
        # --- limiti motore / batteria ---
        add("data:propulsion:%s:battery:voltage" % pid, val=np.nan, units="V")
        add("data:propulsion:%s:battery:resistance" % pid, val=0.0, units="V/A")  # 0 = L0 (no sag)
        add("data:propulsion:%s:motor:speed:constant" % pid, val=np.nan, units="rad/V/s")
        # coppia NOMINALE (continua/termica): il dash e' volo SOSTENUTO, non un picco
        add("data:propulsion:%s:motor:torque:nominal" % pid, val=np.nan, units="N*m")
        add("data:propulsion:%s:motor:power:takeoff" % pid, val=np.nan, units="W")
        # --- parametri per la potenza batteria al dash (energia di missione) ---
        add("data:propulsion:%s:motor:resistance" % pid, val=np.nan, units="V/A")
        add("data:propulsion:%s:motor:torque:friction" % pid, val=np.nan, units="N*m")
        add("data:propulsion:%s:gearbox:N_red" % pid, val=1.0, units=None)
        add("data:propulsion:%s:esc:efficiency" % pid, val=np.nan, units=None)
        add("mission:sizing:payload:power:%s" % pid, val=0.0, units="W")
        # capacita' di potenza della batteria (per il sizing batteria sul dash)
        add("data:propulsion:%s:battery:power:max" % pid, val=np.nan, units="W")
        # --- coefficienti elica (BEMT-fit) ---
        add("data:propulsion:%s:propeller:Ct:dynamic:polynomial" % pid, val=np.nan, shape=12)
        add("data:propulsion:%s:propeller:Cp:dynamic:polynomial" % pid, val=np.nan, shape=12)
        # --- atmosfera ---
        add("mission:sizing:main_route:cruise:altitude", val=150.0, units="m")  # stesso default degli altri moduli
        add("mission:sizing:dISA", val=0.0, units="K")

        c = "optimization:constraints:propulsion:%s:dash" % pid
        self.add_output(c + ":thrust", units=None)    # T >= drag
        self.add_output(c + ":torque", units=None)    # Q <= Qmax
        self.add_output(c + ":power", units=None)     # P <= Pmax
        self.add_output(c + ":mach", units=None)      # Mach punta <= 0.8
        # (rpm eliminato: throttle<=1 garantisce Omega<=Kv*Vbatt;
        #  advance eliminato: throttle>=0.3 tiene i giri alti, niente windmilling)
        # --- SIZING BATTERIA SUL DASH (il dash e' ora scenario di dimensionamento) ---
        self.add_output(c + ":battery:power", units=None)    # P_bat_max >= potenza dash
        self.add_output(c + ":battery:voltage", units=None)  # V_bat >= tensione motore al dash
        # potenza batteria al dash: consumata dall'energia di missione del tratto dash
        self.add_output("data:propulsion:%s:battery:power:dash" % pid, units="W")
        # diagnostici
        self.add_output("data:performance:%s:dash:thrust_available" % pid, units="N")
        self.add_output("data:performance:%s:dash:speed_rot" % pid, units="rad/s")  # Omega_dash calcolato

    def setup_partials(self):
        # formule chiuse e lisce -> complex step (esatto). Se il modello a monte non
        # e' complex-safe, ripiegare su method="fd", step=1e-6.
        self.declare_partials("*", "*", method="fd", step=1e-6)

    def compute(self, inputs, outputs):
        pid = self.options["propulsion_id"]
        s = lambda k: float(np.ravel(inputs[k])[0])
        throttle = s("optimization:variables:propulsion:%s:dash:throttle" % pid)
        V = s("mission:sizing:dash:speed:%s" % pid)
        D = s("data:propulsion:%s:propeller:diameter" % pid)
        beta = s("data:propulsion:%s:propeller:beta" % pid)
        N = s("data:propulsion:%s:propeller:number" % pid)
        m = s("data:weight:mtow")
        fineness = s("data:geometry:body:fineness")
        Sf = s("data:geometry:projected_area:front")
        St = s("data:geometry:projected_area:top")
        Vbatt = s("data:propulsion:%s:battery:voltage" % pid)
        R_pack = s("data:propulsion:%s:battery:resistance" % pid)  # 0 = L0 (no sag)
        Kv = s("data:propulsion:%s:motor:speed:constant" % pid)
        Q_max = s("data:propulsion:%s:motor:torque:nominal" % pid)  # continua (sostenuto)
        P_max = s("data:propulsion:%s:motor:power:takeoff" % pid)
        ct_dyn = np.asarray(inputs["data:propulsion:%s:propeller:Ct:dynamic:polynomial" % pid])
        cp_dyn = np.asarray(inputs["data:propulsion:%s:propeller:Cp:dynamic:polynomial" % pid])
        alt = s("mission:sizing:main_route:cruise:altitude")
        dISA = s("mission:sizing:dISA")

        atm = Atmosphere(alt, delta_t=dISA, altitude_in_feet=False)
        rho = atm.density
        a_sound = atm.speed_of_sound
        CD0 = MultirotorFlightModel.body_cd0(Sf, fineness, V, rho, atm.kinematic_viscosity)  # build-up

        # --- assetto e spinta richiesta a V_dash (volo livellato, RoC = 0) ---
        alpha = float(np.ravel(
            MultirotorFlightModel.get_angle_of_attack(m, V, 0.0, Sf, St, CD0, 0.0, rho)
        )[0])
        T_req_fus = MultirotorFlightModel.get_thrust(m, V, 0.0, alpha, Sf, St, CD0, 0.0, rho)
        # + drag parassita di bracci e motori esposti (0 se dimensioni non fornite)
        b_arm = s("data:structures:arms:plate:width")
        h_arm = s("data:structures:arms:plate:thickness")
        L_arm = s("data:geometry:arms:length")
        L_mot = s("data:propulsion:%s:motor:length:estimated" % pid)
        D_par = MultirotorFlightModel.parasitic_drag(
            V, alpha, rho, N, b_arm, h_arm, L_arm, d_mot=1.7 * L_mot, L_mot=L_mot
        )
        T_req_pp = (T_req_fus + D_par) / N

        def prop_point(W):
            """Punto elica ai giri W: (T, P, Q per elica)."""
            n = W / (2.0 * np.pi)
            J = V / (n * D)
            ct, cp = PropellerAerodynamicsModel.aero_coefficients_incidence(
                beta, J, alpha, ct_model=ct_dyn, cp_model=cp_dyn
            )
            cp = cp * PropellerAerodynamicsModel.compressibility_penalty(W * D / 2.0 / a_sound)
            T = ct * rho * n**2 * D**4
            P = cp * rho * n**3 * D**5
            return T, P, P / W

        # --- giri al dash = throttle * giri max elettrici; con SAG di tensione (R_pack>0) ---
        # predictor con tensione nominale, poi correzione per il sag (V_load = V - I*R_pack).
        # Con R_pack = 0 (fedelta' L0) -> V_load = Vbatt -> comportamento invariato.
        W_nom = throttle * Kv * Vbatt
        _, P_nom, _ = prop_point(W_nom)
        I_batt = P_nom * N / Vbatt                 # corrente pacco (proxy di picco)
        V_load = Vbatt - I_batt * R_pack           # tensione sotto carico (sag)
        W_dash = throttle * Kv * V_load            # giri reali disponibili sotto sag
        T_pp, P_pp, Q_pp = prop_point(W_dash)

        c = "optimization:constraints:propulsion:%s:dash" % pid
        outputs[c + ":thrust"] = (T_pp - T_req_pp) / T_req_pp
        outputs[c + ":torque"] = (Q_max - Q_pp) / Q_max
        outputs[c + ":power"] = (P_max - P_pp) / P_max
        outputs[c + ":mach"] = (_MACH_TIP_MAX * a_sound - W_dash * D / 2.0) / (_MACH_TIP_MAX * a_sound)
        outputs["data:performance:%s:dash:thrust_available" % pid] = T_pp * N
        outputs["data:performance:%s:dash:speed_rot" % pid] = W_dash

        # --- potenza batteria al dash (per l'energia di missione del tratto dash) ---
        # Catena elettrica del motore identica a FlightPerformanceModel, valutata al punto
        # (Q_pp, W_dash) gia' calcolato sopra (robusto: nessun solver interno).
        N_red = s("data:propulsion:%s:gearbox:N_red" % pid)
        Tf = s("data:propulsion:%s:motor:torque:friction" % pid)
        R_mot = s("data:propulsion:%s:motor:resistance" % pid)
        eta_esc = s("data:propulsion:%s:esc:efficiency" % pid)
        P_payload = s("mission:sizing:payload:power:%s" % pid)
        T_mot = MotorPerformanceModel.torque(Q_pp, N_red)
        W_mot = MotorPerformanceModel.speed(W_dash, N_red)
        I_mot = MotorPerformanceModel.current(T_mot, Tf, Kv)
        U_mot = MotorPerformanceModel.voltage(I_mot, W_mot, R_mot, Kv)
        P_mot_el = MotorPerformanceModel.power(U_mot, I_mot)
        P_bat_dash = P_mot_el * N / eta_esc + P_payload
        outputs["data:propulsion:%s:battery:power:dash" % pid] = P_bat_dash

        # --- vincoli di SIZING batteria sul dash (stessa forma di battery/constraints.py) ---
        # potenza: la batteria deve erogare la potenza richiesta al dash (come per takeoff/climb/cruise)
        P_bat_max = s("data:propulsion:%s:battery:power:max" % pid)
        outputs[c + ":battery:power"] = (P_bat_max - P_mot_el * N / eta_esc) / P_bat_max
        # tensione: la batteria deve fornire la tensione motore richiesta al dash
        outputs[c + ":battery:voltage"] = (Vbatt - U_mot) / Vbatt
