"""
Battery electrical model (ECM level L1): pack-of-cells + internal resistance + C-rate.

Attivo solo con fidelity="L1_ecm" sul gruppo Battery. Aggiunge la fisica elettrica
mancante nel modello di riscalatura (L0): resistenza interna del pacco (per il sag),
numero di celle, e vincolo di C-rate. NON sostituisce il modello di energia/massa L0
(che resta a monte); lo ARRICCHISCE con grandezze elettriche.

Tutte le relazioni sono algebriche e lisce (compatibili con l'ottimizzatore).
"""
import numpy as np
import openmdao.api as om


class BatteryElectricalModel(om.ExplicitComponent):
    """
    Da tensione/capacita' del pacco (gia' calcolate a monte) e da una CELLA di
    riferimento, ricava numero celle, resistenza interna del pacco e corrente massima
    sostenibile (C-rate). Emette il vincolo di C-rate.

        Ns = V_pack / V_cell_nom          (celle in serie)
        Np = Q_pack / Q_cell              (celle in parallelo)
        R_pack = (Ns / Np) * r_cell       (resistenza interna del pacco)
        I_max_pack = Cmax_cell * Np * Q_cell   (corrente max di scarica)
    """

    def initialize(self):
        self.options.declare("propulsion_id", default="multirotor")

    def setup(self):
        pid = self.options["propulsion_id"]
        add = self.add_input
        # grandezze pacco (dal modello a monte)
        add("data:propulsion:battery:voltage", val=np.nan, units="V")
        add("data:propulsion:battery:capacity", val=np.nan, units="A*s")
        add("data:propulsion:battery:power:max", val=np.nan, units="W")
        # parametri cella di riferimento (racing)
        add("models:propulsion:battery:cell:voltage:reference", val=3.7, units="V")
        add("models:propulsion:battery:cell:capacity:reference", val=5400.0, units="A*s")  # 1.5 Ah
        add("models:propulsion:battery:cell:resistance:reference", val=2.5e-3, units="V/A")  # 2.5 mOhm
        add("models:propulsion:battery:cell:Crate:max:reference", val=100.0, units="1/h")

        # uscite
        self.add_output("data:propulsion:battery:resistance", units="V/A")
        self.add_output("data:propulsion:battery:current:max:crate", units="A")
        self.add_output("data:propulsion:battery:ecm:number:series", units=None)
        self.add_output("data:propulsion:battery:ecm:number:parallel", units=None)
        self.add_output("data:propulsion:battery:ecm:Crate:required", units="1/h")
        # vincolo C-rate: I_max_crate >= I richiesta di picco (usa power:max come proxy)
        self.add_output("optimization:constraints:propulsion:battery:crate", units=None)

    def setup_partials(self):
        self.declare_partials("*", "*", method="fd", step=1e-6)

    def compute(self, inputs, outputs):
        s = lambda k: float(np.ravel(inputs[k])[0])
        V_pack = s("data:propulsion:battery:voltage")
        Q_pack = s("data:propulsion:battery:capacity")            # [A*s]
        P_max = s("data:propulsion:battery:power:max")            # [W]
        V_cell = s("models:propulsion:battery:cell:voltage:reference")
        Q_cell = s("models:propulsion:battery:cell:capacity:reference")
        r_cell = s("models:propulsion:battery:cell:resistance:reference")
        Cmax = s("models:propulsion:battery:cell:Crate:max:reference")  # [1/h]

        # numero celle (floor fisico: >= 1, niente frazioni assurde nell'ottimizzazione)
        Ns = max(1.0, V_pack / V_cell)             # celle in serie
        Np = max(1.0, Q_pack / Q_cell)             # celle in parallelo
        R_pack = (Ns / Np) * r_cell                # [ohm]

        Q_Ah = Q_pack / 3600.0
        I_max_crate = Cmax * Q_Ah                  # [A] corrente max erogabile
        I_peak = P_max / V_pack                     # [A] corrente di picco richiesta
        Crate_req = I_peak / Q_Ah                   # [1/h] C-rate effettivo richiesto

        outputs["data:propulsion:battery:resistance"] = R_pack
        outputs["data:propulsion:battery:current:max:crate"] = I_max_crate
        outputs["data:propulsion:battery:ecm:number:series"] = Ns
        outputs["data:propulsion:battery:ecm:number:parallel"] = Np
        outputs["data:propulsion:battery:ecm:Crate:required"] = Crate_req
        outputs["optimization:constraints:propulsion:battery:crate"] = (
            (I_max_crate - I_peak) / I_max_crate
        )
