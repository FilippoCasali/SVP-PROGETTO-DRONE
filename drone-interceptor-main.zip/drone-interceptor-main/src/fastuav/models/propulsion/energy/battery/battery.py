"""
Battery component
"""

import fastoad.api as oad
import openmdao.api as om

from fastuav.models.propulsion.energy.battery.catalogue import BatteryCatalogueSelection
from fastuav.models.propulsion.energy.battery.constraints import BatteryConstraints
from fastuav.models.propulsion.energy.battery.definition_parameters import (
    BatteryDefinitionParameters,
)
from fastuav.models.propulsion.energy.battery.estimation_models import (
    BatteryEstimationModels,
)
from fastuav.models.propulsion.energy.battery.performance_analysis import (
    BatteryPerformanceGroup,
)
from fastuav.models.propulsion.energy.battery.electrical_model import BatteryElectricalModel


@oad.RegisterOpenMDAOSystem("fastuav.propulsion.battery")
class Battery(om.Group):
    """
    Group containing the Battery MDA.

    Opzione 'fidelity':
      - "L0_scaling" (default): modello originale (riscalatura energia/massa, tensione libera).
      - "L1_ecm": aggiunge il modello elettrico a celle (resistenza interna -> sag, C-rate).
                  R_pack viene letto a valle (es. modulo dash) per applicare il sag.
    """

    def initialize(self):
        self.options.declare("off_the_shelf", default=False, types=bool)
        self.options.declare(
            "fidelity", default="L0_scaling", values=["L0_scaling", "L1_ecm"]
        )

    def setup(self):
        self.add_subsystem("definition_parameters", BatteryDefinitionParameters(), promotes=["*"])
        self.add_subsystem("estimation_models", BatteryEstimationModels(), promotes=["*"])
        self.add_subsystem(
            "catalogue_selection" if self.options["off_the_shelf"] else "skip_catalogue_selection",
            BatteryCatalogueSelection(off_the_shelf=self.options["off_the_shelf"]),
            promotes=["*"],
        )
        self.add_subsystem("performance_analysis", BatteryPerformanceGroup(), promotes=["*"])
        if self.options["fidelity"] == "L1_ecm":
            self.add_subsystem("electrical_model", BatteryElectricalModel(), promotes=["*"])
        self.add_subsystem("constraints", BatteryConstraints(), promotes=["*"])
