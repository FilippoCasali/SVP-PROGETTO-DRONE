"""
Propeller surrogate models describing the propeller's aerodynamics performance.

Fisica pura estratta in fastuav.physics.propeller (re-export per compatibilita').
I componenti OpenMDAO importano questa classe da qui come prima.
"""

from fastuav.physics.propeller import PropellerAerodynamicsModel  # noqa: F401
