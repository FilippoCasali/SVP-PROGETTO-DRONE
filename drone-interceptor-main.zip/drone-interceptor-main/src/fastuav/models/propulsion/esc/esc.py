"""
ESC component
"""

import fastoad.api as oad
import openmdao.api as om

from fastuav.models.propulsion.esc.catalogue import ESCCatalogueSelection
from fastuav.models.propulsion.esc.constraints import ESCConstraints
from fastuav.models.propulsion.esc.definition_parameters import ESCDefinitionParameters
from fastuav.models.propulsion.esc.estimation_models import ESCEstimationModels
from fastuav.models.propulsion.esc.performance_analysis import ESCPerformanceGroup
from fastuav.models.propulsion.esc.current_model import ESCCurrentModel


@oad.RegisterOpenMDAOSystem("fastuav.propulsion.esc")
class ESC(om.Group):
    """
    Group containing the Electronic Speed Controller analysis.

    Opzione 'fidelity':
      - "L0_power" (default): dimensionamento in potenza (modello originale), efficienza
        costante. Snap COTS su potenza+tensione.
      - "L1_current": aggiunge il modello in corrente (rating continuo/burst, perdite
        MOSFET -> rendimento variabile, massa da densita' di corrente). Grandezza nativa
        dei cataloghi ESC.
    """

    def initialize(self):
        self.options.declare("off_the_shelf", default=False, types=bool)
        self.options.declare("fidelity", default="L0_power", values=["L0_power", "L1_current"])

    def setup(self):
        self.add_subsystem("definition_parameters", ESCDefinitionParameters(), promotes=["*"])
        self.add_subsystem("estimation_models", ESCEstimationModels(), promotes=["*"])
        self.add_subsystem(
            "catalogue_selection" if self.options["off_the_shelf"] else "skip_catalogue_selection",
            ESCCatalogueSelection(off_the_shelf=self.options["off_the_shelf"]),
            promotes=["*"],
        )
        self.add_subsystem("performance_analysis", ESCPerformanceGroup(), promotes=["*"])
        if self.options["fidelity"] == "L1_current":
            self.add_subsystem("current_model", ESCCurrentModel(), promotes=["*"])
        self.add_subsystem("constraints", ESCConstraints(), promotes=["*"])
