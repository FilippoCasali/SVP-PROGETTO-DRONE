"""
ESC current-based model (fidelity L1): rating in corrente + perdite MOSFET + massa.

Attivo solo con fidelity="L1_current" sul gruppo ESC. Sostituisce l'approccio in
potenza (L0) con un modello fisico basato sulla CORRENTE (grandezza nativa dei cataloghi
ESC, es. "30A", "55A"):
  - rating continuo e di burst dalla corrente motore per fase;
  - perdite MOSFET (conduzione I^2*R + commutazione) -> rendimento variabile;
  - massa da densita' di corrente.

Tutte le relazioni sono algebriche e lisce (compatibili con l'ottimizzatore).
Non sostituisce il calcolo in potenza a monte: lo ARRICCHISCE con grandezze in corrente.
"""
import numpy as np
import openmdao.api as om


class ESCCurrentModel(om.ExplicitComponent):
    """
    Da correnti motore per fase + parametri MOSFET calcola: corrente ESC (cont/burst),
    perdite, rendimento variabile e massa da densita' di corrente.

        I_esc_peak  = I_mot_takeoff (fase piu' gravosa in corrente)
        I_cont_req  = max(I_mot_climb, I_mot_cruise)  (correnti sostenute)
        rating_cont = k_margin * I_cont_req
        rating_burst= f_burst * rating_cont
        P_loss      = n_fasi * (I^2 * R_ds_on) + k_sw * f_pwm * U_bat * I
        eta         = P_out / (P_out + P_loss)
        m_esc       = rating_cont / rho_I
    """

    def initialize(self):
        self.options.declare("propulsion_id", default="multirotor")

    def setup(self):
        add = self.add_input
        # correnti motore per fase (gia' calcolate dal modello motore)
        add("data:propulsion:motor:current:takeoff", val=np.nan, units="A")
        add("data:propulsion:motor:current:climb", val=1.0, units="A")
        add("data:propulsion:motor:current:cruise", val=1.0, units="A")
        add("data:propulsion:battery:voltage", val=np.nan, units="V")
        add("data:propulsion:motor:power:takeoff", val=np.nan, units="W")  # potenza di picco (per eta)
        # parametri MOSFET / ESC (cella di riferimento)
        add("models:propulsion:esc:mosfet:resistance:reference", val=1.5e-3, units="V/A")  # R_ds_on
        add("models:propulsion:esc:pwm:frequency:reference", val=24000.0, units="1/s")
        add("models:propulsion:esc:switching:coefficient", val=2.0e-8, units=None)
        add("models:propulsion:esc:current:margin", val=1.15, units=None)   # +15% sopra il continuo
        add("models:propulsion:esc:current:burst_factor", val=1.4, units=None)
        add("models:propulsion:esc:current:density:reference", val=1.5, units="A/g")  # massa
        add("data:propulsion:esc:phases:number", val=3.0, units=None)

        self.add_output("data:propulsion:esc:current:continuous", units="A")
        self.add_output("data:propulsion:esc:current:burst", units="A")
        self.add_output("data:propulsion:esc:efficiency:current_model", units=None)
        self.add_output("data:weight:propulsion:esc:mass:current_model", units="kg")
        # vincolo: il rating di burst copre il picco (takeoff/dash)
        self.add_output("optimization:constraints:propulsion:esc:current", units=None)

    def setup_partials(self):
        self.declare_partials("*", "*", method="fd", step=1e-6)

    def compute(self, inputs, outputs):
        s = lambda k: float(np.ravel(inputs[k])[0])
        I_to = s("data:propulsion:motor:current:takeoff")
        I_cl = s("data:propulsion:motor:current:climb")
        I_cr = s("data:propulsion:motor:current:cruise")
        U_bat = s("data:propulsion:battery:voltage")
        P_out = s("data:propulsion:motor:power:takeoff")
        R_ds = s("models:propulsion:esc:mosfet:resistance:reference")
        f_pwm = s("models:propulsion:esc:pwm:frequency:reference")
        k_sw = s("models:propulsion:esc:switching:coefficient")
        k_margin = s("models:propulsion:esc:current:margin")
        f_burst = s("models:propulsion:esc:current:burst_factor")
        rho_I = s("models:propulsion:esc:current:density:reference")
        n_ph = s("data:propulsion:esc:phases:number")

        I_cont_req = max(I_cl, I_cr)                 # corrente sostenuta piu' alta
        I_peak = I_to                                 # picco (takeoff)
        rating_cont = k_margin * I_cont_req
        rating_burst = f_burst * rating_cont

        # perdite MOSFET al picco (conduzione I^2*R + commutazione)
        P_cond = n_ph * I_peak**2 * R_ds
        P_sw = k_sw * f_pwm * U_bat * I_peak
        P_loss = P_cond + P_sw
        eta = P_out / (P_out + P_loss) if (P_out + P_loss) > 0 else 0.95

        m_esc = rating_cont / rho_I / 1000.0          # A / (A/g) -> g -> kg

        outputs["data:propulsion:esc:current:continuous"] = rating_cont
        outputs["data:propulsion:esc:current:burst"] = rating_burst
        outputs["data:propulsion:esc:efficiency:current_model"] = eta
        outputs["data:weight:propulsion:esc:mass:current_model"] = m_esc
        # vincolo: il rating di burst deve coprire il picco di corrente
        outputs["optimization:constraints:propulsion:esc:current"] = (
            (rating_burst - I_peak) / rating_burst
        )
